import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.List;

/**
 * Unit tests for {@link AppointmentService} — Milestone Three (Algorithms & Data Structures).
 *
 * <p>Covers CRUD operations and the new algorithm methods:
 * {@code getAllAppointments()}, {@code searchByDescription()}, and {@code sortByDate()}.</p>
 *
 * @author Abimbola Alao
 * @version 2.1
 */
public class AppointmentServiceTest {

    private IAppointmentService service;
    private Date date1, date2, date3;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        date1 = new Date(System.currentTimeMillis() + 3_600_000L);   // +1 hour
        date2 = new Date(System.currentTimeMillis() + 7_200_000L);   // +2 hours
        date3 = new Date(System.currentTimeMillis() + 10_800_000L);  // +3 hours
    }

    @Test
    @DisplayName("addAppointment – success path")
    void testAddAppointment() {
        service.addAppointment(new Appointment("1", date1, "Meeting"));
        assertNotNull(service.getAppointment("1"));
    }

    @Test
    @DisplayName("addAppointment – duplicate ID throws")
    void testAddDuplicateAppointment() {
        service.addAppointment(new Appointment("1", date1, "Meeting"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addAppointment(new Appointment("1", date2, "Call")));
    }

    @Test
    @DisplayName("deleteAppointment – null ID throws")
    void testDeleteNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }

    // getAllAppointments
    @Test
    @DisplayName("getAllAppointments – returns all appointments")
    void testGetAllAppointments() {
        service.addAppointment(new Appointment("1", date1, "Meeting"));
        service.addAppointment(new Appointment("2", date2, "Call"));
        assertEquals(2, service.getAllAppointments().size());
    }

    @Test
    @DisplayName("getAllAppointments – empty service returns empty list")
    void testGetAllAppointmentsEmpty() {
        assertTrue(service.getAllAppointments().isEmpty());
    }

    @Test
    @DisplayName("getAllAppointments – preserves insertion order")
    void testGetAllAppointmentsOrder() {
        service.addAppointment(new Appointment("1", date1, "First"));
        service.addAppointment(new Appointment("2", date2, "Second"));
        List<Appointment> all = service.getAllAppointments();
        assertEquals("1", all.get(0).getAppointmentId());
        assertEquals("2", all.get(1).getAppointmentId());
    }

    // searchByDescription
    @Test
    @DisplayName("searchByDescription – matches partial description (case-insensitive)")
    void testSearchByDescription() {
        service.addAppointment(new Appointment("1", date1, "Doctor Visit"));
        service.addAppointment(new Appointment("2", date2, "Team Meeting"));
        List<Appointment> results = service.searchByDescription("doctor");
        assertEquals(1, results.size());
        assertEquals("Doctor Visit", results.get(0).getDescription());
    }

    @Test
    @DisplayName("searchByDescription – no match returns empty list")
    void testSearchByDescriptionNoMatch() {
        service.addAppointment(new Appointment("1", date1, "Doctor Visit"));
        assertTrue(service.searchByDescription("xyz").isEmpty());
    }

    @Test
    @DisplayName("searchByDescription – null query throws")
    void testSearchByDescriptionNull() {
        assertThrows(IllegalArgumentException.class,
                () -> service.searchByDescription(null));
    }

    // sortByDate
    @Test
    @DisplayName("sortByDate – returns appointments in chronological order")
    void testSortByDate() {
        // Add in reverse order
        service.addAppointment(new Appointment("3", date3, "Third"));
        service.addAppointment(new Appointment("1", date1, "First"));
        service.addAppointment(new Appointment("2", date2, "Second"));
        List<Appointment> sorted = service.sortByDate();
        assertTrue(sorted.get(0).getAppointmentDate().before(sorted.get(1).getAppointmentDate()));
        assertTrue(sorted.get(1).getAppointmentDate().before(sorted.get(2).getAppointmentDate()));
        assertEquals("First",  sorted.get(0).getDescription());
        assertEquals("Second", sorted.get(1).getDescription());
        assertEquals("Third",  sorted.get(2).getDescription());
    }

    @Test
    @DisplayName("sortByDate – does not alter insertion order")
    void testSortByDateDoesNotAffectInsertionOrder() {
        service.addAppointment(new Appointment("3", date3, "Third"));
        service.addAppointment(new Appointment("1", date1, "First"));
        service.sortByDate();
        List<Appointment> all = service.getAllAppointments();
        assertEquals("3", all.get(0).getAppointmentId()); // insertion order preserved
    }

    @Test
    @DisplayName("sortByDate – empty service returns empty list")
    void testSortByDateEmpty() {
        assertTrue(service.sortByDate().isEmpty());
    }
}
