import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * In-memory implementation of {@link IAppointmentService}.
 *
 * <h2>Data Structure Choice</h2>
 * <p>Appointments are stored in a {@link LinkedHashMap} keyed by appointment ID.
 * This is a deliberate upgrade from the original {@code HashMap}: appointments
 * are inherently time-ordered entities, and preserving insertion order means that
 * {@link #getAllAppointments()} returns them in the sequence they were scheduled,
 * which is the most natural default view for a calendar-style feature.</p>
 *
 * <p>Time-complexity summary:</p>
 * <ul>
 *   <li>add / delete / lookup: O(1) average case</li>
 *   <li>{@link #getAllAppointments()}: O(n)</li>
 *   <li>{@link #searchByDescription(String)}: O(n)</li>
 *   <li>{@link #sortByDate()}: O(n log n)</li>
 * </ul>
 *
 * <h2>Algorithm Design Notes</h2>
 * <p>{@link #sortByDate()} sorts by {@link Appointment#getAppointmentDate()},
 * which returns a {@link Date} object. {@code Date} implements {@link Comparable},
 * so {@code Comparator.comparing(Appointment::getAppointmentDate)} produces a
 * natural chronological ordering with no custom comparison logic required.</p>
 *
 * @author Abimbola Alao
 * @version 2.1
 * @see IAppointmentService
 */
public class AppointmentService implements IAppointmentService {

    /** Logger for this class. */
    private static final Logger LOGGER =
            Logger.getLogger(AppointmentService.class.getName());

    /**
     * Internal storage: appointmentId → Appointment.
     * LinkedHashMap preserves insertion order for predictable list output.
     */
    private final Map<String, Appointment> appointments;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a new, empty {@code AppointmentService}.
     */
    public AppointmentService() {
        this.appointments = new LinkedHashMap<>();
        LOGGER.info("AppointmentService initialised (LinkedHashMap).");
    }

    // -----------------------------------------------------------------------
    // IAppointmentService — CRUD
    // -----------------------------------------------------------------------

    /** {@inheritDoc} */
    @Override
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            LOGGER.warning("addAppointment called with null appointment.");
            throw new IllegalArgumentException("Appointment cannot be null.");
        }
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            LOGGER.warning("addAppointment failed: duplicate ID '" + id + "'.");
            throw new IllegalArgumentException("Appointment ID already exists: " + id);
        }
        appointments.put(id, appointment);
        LOGGER.info("Appointment added. ID='" + id + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            LOGGER.warning("deleteAppointment failed: ID '" + appointmentId + "' not found.");
            throw new IllegalArgumentException("Appointment ID not found: " + appointmentId);
        }
        appointments.remove(appointmentId);
        LOGGER.info("Appointment deleted. ID='" + appointmentId + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public void updateAppointmentDate(String appointmentId, Date newDate) {
        requireAppointment(appointmentId, "updateAppointmentDate")
                .setAppointmentDate(newDate);
        LOGGER.info("Appointment date updated. ID='" + appointmentId + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public void updateAppointmentDescription(String appointmentId, String description) {
        requireAppointment(appointmentId, "updateAppointmentDescription")
                .setDescription(description);
        LOGGER.info("Appointment description updated. ID='" + appointmentId + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    // -----------------------------------------------------------------------
    // IAppointmentService — Algorithm enhancements (v2.1)
    // -----------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * <p>Returns appointments in insertion order (preserved by LinkedHashMap).
     * Time complexity: O(n).</p>
     */
    @Override
    public List<Appointment> getAllAppointments() {
        List<Appointment> all = new ArrayList<>(appointments.values());
        LOGGER.info("getAllAppointments: returning " + all.size() + " appointment(s).");
        return all;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Uses {@code Stream.filter()} with a case-insensitive
     * {@code contains} predicate on the description field.
     * Time complexity: O(n).</p>
     */
    @Override
    public List<Appointment> searchByDescription(String query) {
        if (query == null) {
            LOGGER.warning("searchByDescription called with null query.");
            throw new IllegalArgumentException("Search query cannot be null.");
        }
        String lower = query.toLowerCase();
        List<Appointment> results = appointments.values().stream()
                .filter(a -> a.getDescription().toLowerCase().contains(lower))
                .collect(Collectors.toList());
        LOGGER.info("searchByDescription('" + query + "'): " + results.size() + " result(s).");
        return results;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Copies the map values into a new list and sorts using
     * {@code Comparator.comparing(Appointment::getAppointmentDate)}.
     * {@link Date} is {@link Comparable}, so natural ordering gives
     * ascending chronological order (earliest first).
     * Time complexity: O(n log n). Internal map is not mutated.</p>
     */
    @Override
    public List<Appointment> sortByDate() {
        List<Appointment> sorted = new ArrayList<>(appointments.values());
        sorted.sort(Comparator.comparing(Appointment::getAppointmentDate));
        LOGGER.info("sortByDate: returning " + sorted.size() + " appointment(s) sorted.");
        return sorted;
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Retrieves an appointment or throws {@link IllegalArgumentException} if
     * not found.
     *
     * @param appointmentId the ID to look up
     * @param methodName    calling method name (for logging)
     * @return the found {@link Appointment}; never {@code null}
     */
    private Appointment requireAppointment(String appointmentId, String methodName) {
        Appointment appointment = appointments.get(appointmentId);
        if (appointment == null) {
            LOGGER.warning(methodName + " failed: ID '" + appointmentId + "' not found.");
            throw new IllegalArgumentException("Appointment ID not found: " + appointmentId);
        }
        return appointment;
    }
}
