import java.util.Date;
import java.util.List;

/**
 * IAppointmentService defines the public contract for any appointment management service.
 *
 * <p>Algorithm and data structure enhancements in v2.1 add:</p>
 * <ul>
 *   <li>{@link #getAllAppointments()} – O(n) retrieval in insertion order</li>
 *   <li>{@link #searchByDescription(String)} – O(n) Stream-based search</li>
 *   <li>{@link #sortByDate()} – O(n log n) chronological sort</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.1
 */
public interface IAppointmentService {

    /**
     * Adds a new appointment to the service.
     *
     * @param appointment the {@link Appointment} to add; must not be {@code null}
     * @throws IllegalArgumentException if the appointment is {@code null} or an
     *                                  appointment with the same ID already exists
     */
    void addAppointment(Appointment appointment);

    /**
     * Deletes the appointment identified by the given ID.
     *
     * @param appointmentId the unique identifier of the appointment to remove
     * @throws IllegalArgumentException if {@code appointmentId} is {@code null}
     *                                  or no appointment with that ID exists
     */
    void deleteAppointment(String appointmentId);

    /**
     * Updates the date of an existing appointment.
     *
     * @param appointmentId the unique identifier of the appointment to update
     * @param newDate       the new appointment date; must be a future date
     * @throws IllegalArgumentException if the appointment is not found or date is invalid
     */
    void updateAppointmentDate(String appointmentId, Date newDate);

    /**
     * Updates the description of an existing appointment.
     *
     * @param appointmentId the unique identifier of the appointment to update
     * @param description   the new description
     * @throws IllegalArgumentException if the appointment is not found or value is invalid
     */
    void updateAppointmentDescription(String appointmentId, String description);

    /**
     * Retrieves the appointment with the given ID.
     *
     * <p>Time complexity: O(1) average case.</p>
     *
     * @param appointmentId the unique identifier to look up
     * @return the matching {@link Appointment}, or {@code null} if not found
     */
    Appointment getAppointment(String appointmentId);

    /**
     * Returns all appointments in insertion order.
     *
     * <p>Time complexity: O(n). Insertion order is preserved by the
     * underlying {@link java.util.LinkedHashMap}.</p>
     *
     * @return a new {@link List} of all appointments; never {@code null}
     */
    List<Appointment> getAllAppointments();

    /**
     * Returns all appointments whose description contains the given query
     * string (case-insensitive).
     *
     * <p>Time complexity: O(n).</p>
     *
     * @param query the substring to search for; must not be {@code null}
     * @return a {@link List} of matching appointments; never {@code null}
     * @throws IllegalArgumentException if {@code query} is {@code null}
     */
    List<Appointment> searchByDescription(String query);

    /**
     * Returns all appointments sorted in ascending chronological order
     * (earliest date first).
     *
     * <p>Time complexity: O(n log n). The internal map is not modified.</p>
     *
     * @return a new sorted {@link List} of all appointments; never {@code null}
     */
    List<Appointment> sortByDate();
}
