import java.util.List;

/**
 * ITaskService defines the public contract for any task management service.
 *
 * <p>Algorithm and data structure enhancements in v2.1 add:</p>
 * <ul>
 *   <li>{@link #getAllTasks()} – O(n) retrieval of all tasks</li>
 *   <li>{@link #searchByName(String)} – O(n) Stream-based name search</li>
 *   <li>{@link #sortByName()} – O(n log n) alphabetical sort</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.1
 */
public interface ITaskService {

    /**
     * Adds a new task to the service.
     *
     * @param task the {@link Task} to add; must not be {@code null}
     * @throws IllegalArgumentException if the task is {@code null} or a task
     *                                  with the same ID already exists
     */
    void addTask(Task task);

    /**
     * Deletes the task identified by the given ID.
     *
     * @param taskId the unique identifier of the task to remove
     * @throws IllegalArgumentException if {@code taskId} is {@code null} or
     *                                  no task with that ID exists
     */
    void deleteTask(String taskId);

    /**
     * Updates the name of an existing task.
     *
     * @param taskId the unique identifier of the task to update
     * @param name   the new task name
     * @throws IllegalArgumentException if the task is not found or value is invalid
     */
    void updateTaskName(String taskId, String name);

    /**
     * Updates the description of an existing task.
     *
     * @param taskId      the unique identifier of the task to update
     * @param description the new description
     * @throws IllegalArgumentException if the task is not found or value is invalid
     */
    void updateTaskDescription(String taskId, String description);

    /**
     * Retrieves the task with the given ID.
     *
     * <p>Time complexity: O(1) average case.</p>
     *
     * @param taskId the unique identifier to look up
     * @return the matching {@link Task}, or {@code null} if not found
     */
    Task getTask(String taskId);

    /**
     * Returns all tasks as a list in insertion order.
     *
     * <p>Time complexity: O(n).</p>
     *
     * @return a new {@link List} of all tasks; never {@code null}
     */
    List<Task> getAllTasks();

    /**
     * Returns all tasks whose name contains the given query string
     * (case-insensitive).
     *
     * <p>Time complexity: O(n).</p>
     *
     * @param query the substring to search for; must not be {@code null}
     * @return a {@link List} of matching tasks; never {@code null}
     * @throws IllegalArgumentException if {@code query} is {@code null}
     */
    List<Task> searchByName(String query);

    /**
     * Returns all tasks sorted alphabetically by name (case-insensitive).
     *
     * <p>Time complexity: O(n log n).</p>
     *
     * @return a new sorted {@link List} of all tasks; never {@code null}
     */
    List<Task> sortByName();
}
