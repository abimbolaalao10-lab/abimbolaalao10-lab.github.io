import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.List;

/**
 * Unit tests for {@link TaskService} — Milestone Three (Algorithms & Data Structures).
 *
 * <p>Covers CRUD operations and the new algorithm methods:
 * {@code getAllTasks()}, {@code searchByName()}, and {@code sortByName()}.</p>
 *
 * @author Abimbola Alao
 * @version 2.1
 */
public class TaskServiceTest {

    private ITaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    @DisplayName("addTask – success path")
    void testAddTask() {
        Task t = new Task("1", "Task One", "Description One");
        service.addTask(t);
        assertNotNull(service.getTask("1"));
    }

    @Test
    @DisplayName("addTask – duplicate ID throws")
    void testAddDuplicateTask() {
        service.addTask(new Task("1", "Task One", "Desc One"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addTask(new Task("1", "Task Two", "Desc Two")));
    }

    @Test
    @DisplayName("deleteTask – success path")
    void testDeleteTask() {
        service.addTask(new Task("2", "Task", "Description"));
        service.deleteTask("2");
        assertNull(service.getTask("2"));
    }

    @Test
    @DisplayName("deleteTask – null ID throws")
    void testDeleteTaskNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }

    // getAllTasks
    @Test
    @DisplayName("getAllTasks – returns all tasks")
    void testGetAllTasks() {
        service.addTask(new Task("1", "Alpha Task", "Desc"));
        service.addTask(new Task("2", "Beta Task",  "Desc"));
        assertEquals(2, service.getAllTasks().size());
    }

    @Test
    @DisplayName("getAllTasks – empty service returns empty list")
    void testGetAllTasksEmpty() {
        assertTrue(service.getAllTasks().isEmpty());
    }

    @Test
    @DisplayName("getAllTasks – preserves insertion order")
    void testGetAllTasksOrder() {
        service.addTask(new Task("1", "First",  "Desc"));
        service.addTask(new Task("2", "Second", "Desc"));
        List<Task> all = service.getAllTasks();
        assertEquals("1", all.get(0).getTaskId());
        assertEquals("2", all.get(1).getTaskId());
    }

    // searchByName
    @Test
    @DisplayName("searchByName – matches partial name (case-insensitive)")
    void testSearchByName() {
        service.addTask(new Task("1", "Alpha Task", "Desc"));
        service.addTask(new Task("2", "Beta Task",  "Desc"));
        List<Task> results = service.searchByName("alpha");
        assertEquals(1, results.size());
        assertEquals("Alpha Task", results.get(0).getName());
    }

    @Test
    @DisplayName("searchByName – no match returns empty list")
    void testSearchByNameNoMatch() {
        service.addTask(new Task("1", "Alpha Task", "Desc"));
        assertTrue(service.searchByName("xyz").isEmpty());
    }

    @Test
    @DisplayName("searchByName – null query throws")
    void testSearchByNameNull() {
        assertThrows(IllegalArgumentException.class, () -> service.searchByName(null));
    }

    // sortByName
    @Test
    @DisplayName("sortByName – returns tasks in alphabetical order")
    void testSortByName() {
        service.addTask(new Task("1", "Zeta Task",  "Desc"));
        service.addTask(new Task("2", "Alpha Task", "Desc"));
        service.addTask(new Task("3", "Beta Task",  "Desc"));
        List<Task> sorted = service.sortByName();
        assertEquals("Alpha Task", sorted.get(0).getName());
        assertEquals("Beta Task",  sorted.get(1).getName());
        assertEquals("Zeta Task",  sorted.get(2).getName());
    }

    @Test
    @DisplayName("sortByName – does not alter insertion order")
    void testSortByNameDoesNotAffectOrder() {
        service.addTask(new Task("1", "Zeta Task",  "Desc"));
        service.addTask(new Task("2", "Alpha Task", "Desc"));
        service.sortByName();
        List<Task> all = service.getAllTasks();
        assertEquals("1", all.get(0).getTaskId()); // insertion order preserved
    }

    @Test
    @DisplayName("sortByName – empty service returns empty list")
    void testSortByNameEmpty() {
        assertTrue(service.sortByName().isEmpty());
    }
}
