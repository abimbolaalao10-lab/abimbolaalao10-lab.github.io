import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * In-memory implementation of {@link ITaskService}.
 *
 * <h2>Data Structure Choice</h2>
 * <p>Tasks are stored in a {@link LinkedHashMap} keyed by task ID, preserving
 * insertion order for predictable {@link #getAllTasks()} output.</p>
 *
 * <p>Time-complexity summary:</p>
 * <ul>
 *   <li>add / delete / lookup: O(1) average case</li>
 *   <li>{@link #getAllTasks()}: O(n)</li>
 *   <li>{@link #searchByName(String)}: O(n)</li>
 *   <li>{@link #sortByName()}: O(n log n)</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.1
 * @see ITaskService
 */
public class TaskService implements ITaskService {

    /** Logger for this class. */
    private static final Logger LOGGER =
            Logger.getLogger(TaskService.class.getName());

    /**
     * Internal storage: taskId → Task.
     * LinkedHashMap preserves insertion order.
     */
    private final Map<String, Task> tasks;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a new, empty {@code TaskService}.
     */
    public TaskService() {
        this.tasks = new LinkedHashMap<>();
        LOGGER.info("TaskService initialised (LinkedHashMap).");
    }

    // -----------------------------------------------------------------------
    // ITaskService — CRUD
    // -----------------------------------------------------------------------

    /** {@inheritDoc} */
    @Override
    public void addTask(Task task) {
        if (task == null) {
            LOGGER.warning("addTask called with null task.");
            throw new IllegalArgumentException("Task cannot be null.");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            LOGGER.warning("addTask failed: duplicate ID '" + id + "'.");
            throw new IllegalArgumentException("Task ID already exists: " + id);
        }
        tasks.put(id, task);
        LOGGER.info("Task added. ID='" + id + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public void deleteTask(String taskId) {
        if (taskId == null || !tasks.containsKey(taskId)) {
            LOGGER.warning("deleteTask failed: ID '" + taskId + "' not found.");
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }
        tasks.remove(taskId);
        LOGGER.info("Task deleted. ID='" + taskId + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public void updateTaskName(String taskId, String name) {
        requireTask(taskId, "updateTaskName").setName(name);
        LOGGER.info("Task name updated. ID='" + taskId + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public void updateTaskDescription(String taskId, String description) {
        requireTask(taskId, "updateTaskDescription").setDescription(description);
        LOGGER.info("Task description updated. ID='" + taskId + "'.");
    }

    /** {@inheritDoc} */
    @Override
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // -----------------------------------------------------------------------
    // ITaskService — Algorithm enhancements (v2.1)
    // -----------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * <p>Time complexity: O(n).</p>
     */
    @Override
    public List<Task> getAllTasks() {
        List<Task> all = new ArrayList<>(tasks.values());
        LOGGER.info("getAllTasks: returning " + all.size() + " task(s).");
        return all;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Uses {@code Stream.filter()} with a case-insensitive
     * {@code contains} predicate on the task name field.
     * Time complexity: O(n).</p>
     */
    @Override
    public List<Task> searchByName(String query) {
        if (query == null) {
            LOGGER.warning("searchByName called with null query.");
            throw new IllegalArgumentException("Search query cannot be null.");
        }
        String lower = query.toLowerCase();
        List<Task> results = tasks.values().stream()
                .filter(t -> t.getName().toLowerCase().contains(lower))
                .collect(Collectors.toList());
        LOGGER.info("searchByName('" + query + "'): " + results.size() + " result(s).");
        return results;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Copies values into a new list and sorts using
     * {@link Comparator#comparing} on the lower-cased task name.
     * Time complexity: O(n log n). Internal map is not mutated.</p>
     */
    @Override
    public List<Task> sortByName() {
        List<Task> sorted = new ArrayList<>(tasks.values());
        sorted.sort(Comparator.comparing(t -> t.getName().toLowerCase()));
        LOGGER.info("sortByName: returning " + sorted.size() + " task(s) sorted.");
        return sorted;
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Retrieves a task or throws {@link IllegalArgumentException} if not found.
     *
     * @param taskId     the ID to look up
     * @param methodName calling method name (for logging)
     * @return the found {@link Task}; never {@code null}
     */
    private Task requireTask(String taskId, String methodName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            LOGGER.warning(methodName + " failed: task ID '" + taskId + "' not found.");
            throw new IllegalArgumentException("Task not found: " + taskId);
        }
        return task;
    }
}
