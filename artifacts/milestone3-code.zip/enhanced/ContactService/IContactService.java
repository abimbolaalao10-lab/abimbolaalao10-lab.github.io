import java.util.List;

/**
 * IContactService defines the public contract for any contact management service.
 *
 * <p>By programming to this interface rather than a concrete implementation,
 * callers remain decoupled from storage details. The implementation can be
 * swapped (e.g. in-memory HashMap vs. a database-backed service) without
 * changing any calling code.</p>
 *
 * <p>Algorithm and data structure enhancements in v2.1 add:</p>
 * <ul>
 *   <li>{@link #getAllContacts()} – O(n) retrieval of all contacts as a sorted list</li>
 *   <li>{@link #searchByName(String)} – O(n) linear scan with Stream filtering</li>
 *   <li>{@link #sortByLastName()} – O(n log n) sort using Comparator</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.1
 */
public interface IContactService {

    /**
     * Adds a new contact to the service.
     *
     * @param contact the {@link Contact} to add; must not be {@code null}
     * @return {@code true} if the contact was successfully added
     * @throws IllegalArgumentException if the contact is {@code null} or a
     *                                  contact with the same ID already exists
     */
    boolean addContact(Contact contact);

    /**
     * Deletes the contact identified by the given ID.
     *
     * @param contactId the unique identifier of the contact to remove;
     *                  must not be {@code null}
     * @return {@code true} if the contact was successfully removed
     * @throws IllegalArgumentException if {@code contactId} is {@code null} or
     *                                  no contact with that ID exists
     */
    boolean deleteContact(String contactId);

    /**
     * Updates the first name of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param firstName the new first name
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or value is invalid
     */
    boolean updateFirstName(String contactId, String firstName);

    /**
     * Updates the last name of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param lastName  the new last name
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or value is invalid
     */
    boolean updateLastName(String contactId, String lastName);

    /**
     * Updates the phone number of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param phone     the new 10-digit phone number
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or value is invalid
     */
    boolean updatePhone(String contactId, String phone);

    /**
     * Updates the address of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param address   the new address
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or value is invalid
     */
    boolean updateAddress(String contactId, String address);

    /**
     * Retrieves the contact with the given ID.
     *
     * <p>Time complexity: O(1) average case (HashMap lookup).</p>
     *
     * @param contactId the unique identifier to look up
     * @return the matching {@link Contact}, or {@code null} if not found
     */
    Contact getContact(String contactId);

    /**
     * Returns all contacts as an unordered list.
     *
     * <p>Time complexity: O(n) where n is the number of stored contacts.</p>
     *
     * @return a new {@link List} containing all contacts; never {@code null},
     *         may be empty
     */
    List<Contact> getAllContacts();

    /**
     * Returns all contacts whose first or last name contains the given
     * search string (case-insensitive).
     *
     * <p>Implemented using Java Streams with a filter predicate, performing
     * a linear O(n) scan of all stored contacts. This is the optimal approach
     * for an unsorted, unindexed in-memory collection.</p>
     *
     * @param query the substring to search for; must not be {@code null}
     * @return a {@link List} of matching contacts; never {@code null},
     *         may be empty
     * @throws IllegalArgumentException if {@code query} is {@code null}
     */
    List<Contact> searchByName(String query);

    /**
     * Returns all contacts sorted alphabetically by last name, then by
     * first name as a tiebreaker.
     *
     * <p>Sorting is performed using {@link java.util.Comparator#comparing}
     * applied to a new {@link List} copied from the internal map values.
     * The internal map is not modified. Time complexity: O(n log n) for
     * the sort step, O(n) for the copy — overall O(n log n).</p>
     *
     * @return a new sorted {@link List} of all contacts; never {@code null},
     *         may be empty
     */
    List<Contact> sortByLastName();
}
