import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.List;

/**
 * Unit tests for {@link ContactService} — Milestone Three (Algorithms & Data Structures).
 *
 * <p>This test class extends the Milestone Two suite with tests covering
 * the new algorithm methods: {@code getAllContacts()}, {@code searchByName()},
 * and {@code sortByLastName()}.</p>
 *
 * @author Abimbola Alao
 * @version 2.1
 */
public class ContactServiceTest {

    private IContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    // -----------------------------------------------------------------------
    // Existing CRUD tests (carried forward from Milestone Two)
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("addContact – success path")
    void testAddContact() {
        Contact c = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertTrue(service.addContact(c));
        assertEquals(c, service.getContact("1234567890"));
    }

    @Test
    @DisplayName("addContact – duplicate ID throws")
    void testAddDuplicateContact() {
        service.addContact(new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addContact(new Contact("1234567890", "Jane", "Smith", "9876543210", "456 Oak Ave")));
    }

    @Test
    @DisplayName("deleteContact – success path")
    void testDeleteContact() {
        service.addContact(new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"));
        assertTrue(service.deleteContact("1234567890"));
        assertNull(service.getContact("1234567890"));
    }

    @Test
    @DisplayName("deleteContact – null ID throws")
    void testDeleteContactNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact(null));
    }

    // -----------------------------------------------------------------------
    // getAllContacts
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("getAllContacts – empty service returns empty list")
    void testGetAllContactsEmpty() {
        List<Contact> all = service.getAllContacts();
        assertNotNull(all);
        assertTrue(all.isEmpty());
    }

    @Test
    @DisplayName("getAllContacts – returns all added contacts")
    void testGetAllContactsReturnsAll() {
        service.addContact(new Contact("1111111111", "Alice", "Brown", "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Bob",   "Adams", "2222222222", "2 B St"));
        service.addContact(new Contact("3333333333", "Carol", "Zara",  "3333333333", "3 C St"));
        assertEquals(3, service.getAllContacts().size());
    }

    @Test
    @DisplayName("getAllContacts – preserves insertion order (LinkedHashMap)")
    void testGetAllContactsInsertionOrder() {
        Contact c1 = new Contact("1111111111", "Alice", "Brown", "1111111111", "1 A St");
        Contact c2 = new Contact("2222222222", "Bob",   "Adams", "2222222222", "2 B St");
        service.addContact(c1);
        service.addContact(c2);
        List<Contact> all = service.getAllContacts();
        assertEquals("1111111111", all.get(0).getContactId());
        assertEquals("2222222222", all.get(1).getContactId());
    }

    // -----------------------------------------------------------------------
    // searchByName
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("searchByName – matches first name (case-insensitive)")
    void testSearchByFirstName() {
        service.addContact(new Contact("1111111111", "Alice", "Brown", "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Bob",   "Adams", "2222222222", "2 B St"));
        List<Contact> results = service.searchByName("ali");
        assertEquals(1, results.size());
        assertEquals("Alice", results.get(0).getFirstName());
    }

    @Test
    @DisplayName("searchByName – matches last name (case-insensitive)")
    void testSearchByLastName() {
        service.addContact(new Contact("1111111111", "Alice", "Brown", "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Bob",   "Adams", "2222222222", "2 B St"));
        List<Contact> results = service.searchByName("ADAMS");
        assertEquals(1, results.size());
        assertEquals("Bob", results.get(0).getFirstName());
    }

    @Test
    @DisplayName("searchByName – returns multiple matches")
    void testSearchByNameMultipleMatches() {
        service.addContact(new Contact("1111111111", "Alice", "Anderson", "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Bob",   "Andrews",  "2222222222", "2 B St"));
        service.addContact(new Contact("3333333333", "Carol", "Brown",    "3333333333", "3 C St"));
        List<Contact> results = service.searchByName("an");
        assertEquals(2, results.size());
    }

    @Test
    @DisplayName("searchByName – no match returns empty list")
    void testSearchByNameNoMatch() {
        service.addContact(new Contact("1111111111", "Alice", "Brown", "1111111111", "1 A St"));
        List<Contact> results = service.searchByName("xyz");
        assertTrue(results.isEmpty());
    }

    @Test
    @DisplayName("searchByName – null query throws")
    void testSearchByNameNullQuery() {
        assertThrows(IllegalArgumentException.class, () -> service.searchByName(null));
    }

    @Test
    @DisplayName("searchByName – empty query matches all contacts")
    void testSearchByNameEmptyQuery() {
        service.addContact(new Contact("1111111111", "Alice", "Brown", "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Bob",   "Adams", "2222222222", "2 B St"));
        List<Contact> results = service.searchByName("");
        assertEquals(2, results.size());
    }

    // -----------------------------------------------------------------------
    // sortByLastName
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("sortByLastName – returns contacts in alphabetical order by last name")
    void testSortByLastName() {
        service.addContact(new Contact("1111111111", "Carol", "Zara",  "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Alice", "Brown", "2222222222", "2 B St"));
        service.addContact(new Contact("3333333333", "Bob",   "Adams", "3333333333", "3 C St"));
        List<Contact> sorted = service.sortByLastName();
        assertEquals("Adams", sorted.get(0).getLastName());
        assertEquals("Brown", sorted.get(1).getLastName());
        assertEquals("Zara",  sorted.get(2).getLastName());
    }

    @Test
    @DisplayName("sortByLastName – tiebreaker: same last name sorted by first name")
    void testSortByLastNameTiebreaker() {
        service.addContact(new Contact("1111111111", "Zack", "Smith", "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Anna", "Smith", "2222222222", "2 B St"));
        List<Contact> sorted = service.sortByLastName();
        assertEquals("Anna", sorted.get(0).getFirstName());
        assertEquals("Zack", sorted.get(1).getFirstName());
    }

    @Test
    @DisplayName("sortByLastName – case-insensitive ordering")
    void testSortByLastNameCaseInsensitive() {
        service.addContact(new Contact("1111111111", "Alice", "zebra",  "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Bob",   "Adams",  "2222222222", "2 B St"));
        List<Contact> sorted = service.sortByLastName();
        assertEquals("Adams", sorted.get(0).getLastName());
        assertEquals("zebra", sorted.get(1).getLastName());
    }

    @Test
    @DisplayName("sortByLastName – does not modify internal insertion order")
    void testSortByLastNameDoesNotAffectInsertionOrder() {
        service.addContact(new Contact("1111111111", "Carol", "Zara",  "1111111111", "1 A St"));
        service.addContact(new Contact("2222222222", "Alice", "Brown", "2222222222", "2 B St"));
        service.sortByLastName(); // sort
        List<Contact> all = service.getAllContacts(); // insertion order must be unchanged
        assertEquals("1111111111", all.get(0).getContactId()); // Carol still first
        assertEquals("2222222222", all.get(1).getContactId()); // Alice still second
    }

    @Test
    @DisplayName("sortByLastName – empty service returns empty list")
    void testSortByLastNameEmpty() {
        assertTrue(service.sortByLastName().isEmpty());
    }
}
