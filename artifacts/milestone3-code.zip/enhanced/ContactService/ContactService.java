import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * In-memory implementation of {@link IContactService}.
 *
 * <h2>Data Structure Choice</h2>
 * <p>Contacts are stored in a {@link LinkedHashMap} keyed by contact ID.
 * {@code LinkedHashMap} was chosen over a plain {@code HashMap} because it
 * preserves insertion order, making the output of {@link #getAllContacts()}
 * predictable and reproducible — an important property for any UI that lists
 * contacts in the order they were added.</p>
 *
 * <p>Time-complexity summary for core operations:</p>
 * <ul>
 *   <li>add / delete / lookup by ID: O(1) average case</li>
 *   <li>{@link #getAllContacts()}: O(n)</li>
 *   <li>{@link #searchByName(String)}: O(n) — linear scan via Stream filter</li>
 *   <li>{@link #sortByLastName()}: O(n log n) — copy then sort</li>
 * </ul>
 *
 * <h2>Algorithm Design Notes</h2>
 * <p>{@link #searchByName(String)} uses the Java Streams API with a
 * case-insensitive {@code contains} predicate. This is a deliberate design
 * choice: for an in-memory collection of this scale, a linear scan is both
 * simple and sufficient. A secondary index (e.g. a sorted tree or inverted
 * index) would reduce search to O(log n) but would add significant complexity
 * and memory overhead that is not justified here.</p>
 *
 * <p>{@link #sortByLastName()} copies the map values into a new
 * {@link ArrayList} and sorts using a two-level {@link Comparator} — last
 * name first, then first name as a tiebreaker. The internal map is never
 * modified, so the stored insertion order is always preserved.</p>
 *
 * @author Abimbola Alao
 * @version 2.1
 * @see IContactService
 */
public class ContactService implements IContactService {

    /** Logger for this class. */
    private static final Logger LOGGER =
            Logger.getLogger(ContactService.class.getName());

    /**
     * Internal storage: contactId → Contact.
     *
     * <p>LinkedHashMap is used instead of HashMap to preserve insertion order,
     * ensuring that getAllContacts() returns contacts in a predictable sequence.</p>
     */
    private final Map<String, Contact> contacts;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a new, empty {@code ContactService} backed by a
     * {@link LinkedHashMap}.
     */
    public ContactService() {
        this.contacts = new LinkedHashMap<>();
        LOGGER.info("ContactService initialised (LinkedHashMap).");
    }

    // -----------------------------------------------------------------------
    // IContactService — CRUD
    // -----------------------------------------------------------------------

    /** {@inheritDoc} */
    @Override
    public boolean addContact(Contact contact) {
        if (contact == null) {
            LOGGER.warning("addContact called with null contact.");
            throw new IllegalArgumentException("Contact cannot be null.");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            LOGGER.warning("addContact failed: duplicate ID '" + id + "'.");
            throw new IllegalArgumentException("Contact ID already exists: " + id);
        }
        contacts.put(id, contact);
        LOGGER.info("Contact added. ID='" + id + "'.");
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public boolean deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            LOGGER.warning("deleteContact failed: ID '" + contactId + "' not found.");
            throw new IllegalArgumentException("Contact ID not found: " + contactId);
        }
        contacts.remove(contactId);
        LOGGER.info("Contact deleted. ID='" + contactId + "'.");
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public boolean updateFirstName(String contactId, String firstName) {
        requireContact(contactId, "updateFirstName").setFirstName(firstName);
        LOGGER.info("First name updated for ID='" + contactId + "'.");
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public boolean updateLastName(String contactId, String lastName) {
        requireContact(contactId, "updateLastName").setLastName(lastName);
        LOGGER.info("Last name updated for ID='" + contactId + "'.");
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public boolean updatePhone(String contactId, String phone) {
        requireContact(contactId, "updatePhone").setPhone(phone);
        LOGGER.info("Phone updated for ID='" + contactId + "'.");
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public boolean updateAddress(String contactId, String address) {
        requireContact(contactId, "updateAddress").setAddress(address);
        LOGGER.info("Address updated for ID='" + contactId + "'.");
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    // -----------------------------------------------------------------------
    // IContactService — Algorithm enhancements (v2.1)
    // -----------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * <p>Implementation: copies the map's value collection into a new
     * {@link ArrayList}. Time complexity: O(n).</p>
     */
    @Override
    public List<Contact> getAllContacts() {
        List<Contact> all = new ArrayList<>(contacts.values());
        LOGGER.info("getAllContacts: returning " + all.size() + " contact(s).");
        return all;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Implementation detail: uses {@code Stream.filter()} with a
     * case-insensitive {@code String.contains()} predicate on both first
     * and last name fields. The stream is collected into a new
     * {@link ArrayList}.</p>
     *
     * <p>Time complexity: O(n) — every contact is visited exactly once.</p>
     *
     * <p>Trade-off: a secondary sorted index (e.g. a {@code TreeMap} keyed
     * by name) would allow O(log n) prefix searches, but at the cost of
     * maintaining two synchronized data structures. For the scale of this
     * application, O(n) is acceptable and the simpler design is preferable.</p>
     */
    @Override
    public List<Contact> searchByName(String query) {
        if (query == null) {
            LOGGER.warning("searchByName called with null query.");
            throw new IllegalArgumentException("Search query cannot be null.");
        }
        String lowerQuery = query.toLowerCase();
        List<Contact> results = contacts.values().stream()
                .filter(c -> c.getFirstName().toLowerCase().contains(lowerQuery)
                          || c.getLastName().toLowerCase().contains(lowerQuery))
                .collect(Collectors.toList());
        LOGGER.info("searchByName('" + query + "'): " + results.size() + " result(s).");
        return results;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Implementation detail: copies the map values into a new
     * {@link ArrayList}, then sorts using a two-level {@link Comparator}:
     * primary key is last name (ascending, case-insensitive), secondary key
     * is first name (ascending, case-insensitive). The internal map is never
     * mutated.</p>
     *
     * <p>Time complexity: O(n log n) — dominated by the sort step.
     * Java's {@code List.sort()} uses TimSort, which is stable and performs
     * well on partially sorted data.</p>
     */
    @Override
    public List<Contact> sortByLastName() {
        List<Contact> sorted = new ArrayList<>(contacts.values());
        sorted.sort(Comparator
                .comparing(c -> c.getLastName().toLowerCase(),
                           Comparator.naturalOrder()));
        // Secondary sort by first name using a chained comparator
        sorted.sort(Comparator
                .comparing((Contact c) -> c.getLastName().toLowerCase())
                .thenComparing(c -> c.getFirstName().toLowerCase()));
        LOGGER.info("sortByLastName: returning " + sorted.size() + " contact(s) sorted.");
        return sorted;
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Retrieves a contact or throws {@link IllegalArgumentException} if not found.
     *
     * @param contactId  the ID to look up
     * @param methodName calling method name (for logging)
     * @return the found {@link Contact}; never {@code null}
     */
    private Contact requireContact(String contactId, String methodName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            LOGGER.warning(methodName + " failed: contact ID '" + contactId + "' not found.");
            throw new IllegalArgumentException("Contact ID not found: " + contactId);
        }
        return contact;
    }
}
