import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000); // 1 hour from now
        Appointment appt = new Appointment("1", futureDate, "Doctor Appointment");
        assertEquals("1", appt.getAppointmentId());
        assertEquals("Doctor Appointment", appt.getDescription());
        assertEquals(futureDate, appt.getAppointmentDate());
    }

    @Test
    void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });
    }

    @Test
    void testPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 3600 * 1000); // 1 hour ago
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", pastDate, "Description");
        });
    }

    @Test
    void testInvalidDescriptionLength() {
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        String longDesc = "This description is definitely longer than fifty characters and should fail";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", futureDate, longDesc);
        });
    }
}
