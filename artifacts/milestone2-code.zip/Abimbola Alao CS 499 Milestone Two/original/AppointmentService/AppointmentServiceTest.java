import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt = new Appointment("1", futureDate, "Meeting");

        service.addAppointment(appt);
        assertNotNull(service.getAppointment("1"));
    }

    @Test
    void testAddDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt1 = new Appointment("1", futureDate, "Meeting 1");
        Appointment appt2 = new Appointment("1", futureDate, "Meeting 2");

        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt = new Appointment("2", futureDate, "Call");

        service.addAppointment(appt);
        service.deleteAppointment("2");

        assertNull(service.getAppointment("2"));
    }
}
