import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContactSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertTrue(contactService.addContact(contact));
        assertEquals(contact, contactService.getContact("1234567890"));
    }

    @Test
    public void testAddContactDuplicateId() {
        Contact contact1 = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("1234567890", "Jane", "Smith", "9876543210", "456 Oak Ave");

        contactService.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
    }

    @Test
    public void testAddNullContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(null);
        });
    }

    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.deleteContact("1234567890"));
        assertNull(contactService.getContact("1234567890"));
    }

    @Test
    public void testDeleteContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("9999999999");
        });
    }

    @Test
    public void testDeleteContactNullId() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact(null);
        });
    }

    @Test
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.updateFirstName("1234567890", "Jane"));
        assertEquals("Jane", contactService.getContact("1234567890").getFirstName());
    }

    @Test
    public void testUpdateFirstNameContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateFirstName("9999999999", "Jane");
        });
    }

    @Test
    public void testUpdateFirstNameInvalidData() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateFirstName("1234567890", "JaneJaneJane");
        });
    }

    @Test
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.updateLastName("1234567890", "Smith"));
        assertEquals("Smith", contactService.getContact("1234567890").getLastName());
    }

    @Test
    public void testUpdateLastNameContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateLastName("9999999999", "Smith");
        });
    }

    @Test
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.updatePhone("1234567890", "9876543210"));
        assertEquals("9876543210", contactService.getContact("1234567890").getPhone());
    }

    @Test
    public void testUpdatePhoneContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updatePhone("9999999999", "9876543210");
        });
    }

    @Test
    public void testUpdatePhoneInvalidData() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updatePhone("1234567890", "123");
        });
    }

    @Test
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.updateAddress("1234567890", "456 Oak Ave"));
        assertEquals("456 Oak Ave", contactService.getContact("1234567890").getAddress());
    }

    @Test
    public void testUpdateAddressContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateAddress("9999999999", "456 Oak Ave");
        });
    }

    @Test
    public void testUpdateAddressInvalidData() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateAddress("1234567890", "123 Main Street, Apartment 456, City, State");
        });
    }

    @Test
    public void testMultipleContacts() {
        Contact contact1 = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("0987654321", "Jane", "Smith", "9876543210", "456 Oak Ave");

        contactService.addContact(contact1);
        contactService.addContact(contact2);

        assertEquals(contact1, contactService.getContact("1234567890"));
        assertEquals(contact2, contactService.getContact("0987654321"));
    }
}