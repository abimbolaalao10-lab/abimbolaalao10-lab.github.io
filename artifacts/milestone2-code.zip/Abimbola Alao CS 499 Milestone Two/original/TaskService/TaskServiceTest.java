import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task One", "Description One");

        service.addTask(task);
        assertNotNull(service.getTask("1"));
    }

    @Test
    void testAddDuplicateTaskId() {
        TaskService service = new TaskService();
        Task task1 = new Task("1", "Task One", "Description One");
        Task task2 = new Task("1", "Task Two", "Description Two");

        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("2", "Task", "Description");

        service.addTask(task);
        service.deleteTask("2");

        assertNull(service.getTask("2"));
    }

    @Test
    void testUpdateTaskName() {
        TaskService service = new TaskService();
        Task task = new Task("3", "Old Name", "Description");

        service.addTask(task);
        service.updateTaskName("3", "New Name");

        assertEquals("New Name", service.getTask("3").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        TaskService service = new TaskService();
        Task task = new Task("4", "Task", "Old Description");

        service.addTask(task);
        service.updateTaskDescription("4", "New Description");

        assertEquals("New Description", service.getTask("4").getDescription());
    }
}
