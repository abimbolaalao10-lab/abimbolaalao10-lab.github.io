import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("12345", "Homework", "Finish CS 320 milestone");
        assertEquals("12345", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Finish CS 320 milestone", task.getDescription());
    }

    @Test
    void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }

    @Test
    void testInvalidNameLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "ThisNameIsWayTooLongToBeValid", "Description");
        });
    }

    @Test
    void testInvalidDescriptionLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Task",
                    "This description is definitely longer than fifty characters and should fail");
        });
    }
}
