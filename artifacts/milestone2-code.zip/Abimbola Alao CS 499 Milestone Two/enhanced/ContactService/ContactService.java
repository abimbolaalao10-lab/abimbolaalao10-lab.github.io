import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * In-memory implementation of {@link IContactService}.
 *
 * <p>All contacts are stored in a {@link HashMap} keyed by contact ID, giving
 * O(1) average-case performance for add, delete, and lookup operations.</p>
 *
 * <p>Every significant operation is recorded through the Java logging framework
 * at {@code INFO} level. Validation failures and unexpected errors are logged
 * at {@code WARNING} or {@code SEVERE} level, providing an audit trail and
 * supporting post-incident diagnosis.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 * @see IContactService
 */
public class ContactService implements IContactService {

    /** Logger for this class. */
    private static final Logger LOGGER =
            Logger.getLogger(ContactService.class.getName());

    /** Internal storage: contactId → Contact. */
    private final Map<String, Contact> contacts;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a new, empty {@code ContactService}.
     */
    public ContactService() {
        this.contacts = new HashMap<>();
        LOGGER.info("ContactService initialised.");
    }

    // -----------------------------------------------------------------------
    // IContactService implementation
    // -----------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * <p>The contact is stored under its {@code contactId}. Duplicate IDs are
     * rejected immediately.</p>
     */
    @Override
    public boolean addContact(Contact contact) {
        if (contact == null) {
            LOGGER.warning("addContact called with null contact.");
            throw new IllegalArgumentException("Contact cannot be null.");
        }

        String id = contact.getContactId();

        if (contacts.containsKey(id)) {
            LOGGER.warning("addContact failed: duplicate ID '" + id + "'.");
            throw new IllegalArgumentException("Contact ID already exists: " + id);
        }

        contacts.put(id, contact);
        LOGGER.info("Contact added successfully. ID='" + id + "'.");
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            LOGGER.warning("deleteContact failed: ID '" + contactId + "' not found.");
            throw new IllegalArgumentException("Contact ID not found: " + contactId);
        }

        contacts.remove(contactId);
        LOGGER.info("Contact deleted. ID='" + contactId + "'.");
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean updateFirstName(String contactId, String firstName) {
        Contact contact = requireContact(contactId, "updateFirstName");
        contact.setFirstName(firstName);
        LOGGER.info("First name updated for ID='" + contactId + "'.");
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean updateLastName(String contactId, String lastName) {
        Contact contact = requireContact(contactId, "updateLastName");
        contact.setLastName(lastName);
        LOGGER.info("Last name updated for ID='" + contactId + "'.");
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean updatePhone(String contactId, String phone) {
        Contact contact = requireContact(contactId, "updatePhone");
        contact.setPhone(phone);
        LOGGER.info("Phone updated for ID='" + contactId + "'.");
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean updateAddress(String contactId, String address) {
        Contact contact = requireContact(contactId, "updateAddress");
        contact.setAddress(address);
        LOGGER.info("Address updated for ID='" + contactId + "'.");
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Contact getContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            LOGGER.fine("getContact: no contact found for ID='" + contactId + "'.");
        }
        return contact;
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Retrieves a contact or throws an {@link IllegalArgumentException} if the
     * ID does not map to an existing contact.
     *
     * <p>Centralising this lookup eliminates repeated null-check boilerplate in
     * every update method and ensures consistent error messages and log entries.</p>
     *
     * @param contactId  the ID to look up
     * @param methodName the calling method name (used in the log message)
     * @return the found {@link Contact}; never {@code null}
     * @throws IllegalArgumentException if the contact does not exist
     */
    private Contact requireContact(String contactId, String methodName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            String msg = methodName + " failed: contact ID '" + contactId + "' not found.";
            LOGGER.warning(msg);
            throw new IllegalArgumentException("Contact ID not found: " + contactId);
        }
        return contact;
    }
}
