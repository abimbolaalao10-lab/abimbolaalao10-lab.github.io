import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link ContactService}.
 *
 * <p>Coverage includes:</p>
 * <ul>
 *   <li>Happy-path CRUD operations</li>
 *   <li>Null and empty input rejection</li>
 *   <li>Boundary values (max-length strings)</li>
 *   <li>Duplicate ID rejection</li>
 *   <li>Update operations on non-existent contacts</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public class ContactServiceTest {

    private IContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    // -----------------------------------------------------------------------
    // addContact
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("addContact – success path")
    public void testAddContactSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertTrue(contactService.addContact(contact));
        assertEquals(contact, contactService.getContact("1234567890"));
    }

    @Test
    @DisplayName("addContact – duplicate ID throws")
    public void testAddContactDuplicateId() {
        Contact c1 = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        Contact c2 = new Contact("1234567890", "Jane", "Smith", "9876543210", "456 Oak Ave");
        contactService.addContact(c1);
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(c2));
    }

    @Test
    @DisplayName("addContact – null contact throws")
    public void testAddNullContact() {
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(null));
    }

    // -----------------------------------------------------------------------
    // deleteContact
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("deleteContact – success path")
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.deleteContact("1234567890"));
        assertNull(contactService.getContact("1234567890"));
    }

    @Test
    @DisplayName("deleteContact – non-existent ID throws")
    public void testDeleteContactNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.deleteContact("9999999999"));
    }

    @Test
    @DisplayName("deleteContact – null ID throws")
    public void testDeleteContactNullId() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.deleteContact(null));
    }

    // -----------------------------------------------------------------------
    // updateFirstName
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("updateFirstName – success path")
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updateFirstName("1234567890", "Jane"));
        assertEquals("Jane", contactService.getContact("1234567890").getFirstName());
    }

    @Test
    @DisplayName("updateFirstName – boundary: exactly 10 characters accepted")
    public void testUpdateFirstNameBoundaryAccepted() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updateFirstName("1234567890", "JohnJohnJo")); // 10 chars
    }

    @Test
    @DisplayName("updateFirstName – 11 characters rejected")
    public void testUpdateFirstNameTooLong() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateFirstName("1234567890", "JohnJohnJoh")); // 11 chars
    }

    @Test
    @DisplayName("updateFirstName – null value rejected")
    public void testUpdateFirstNameNull() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateFirstName("1234567890", null));
    }

    @Test
    @DisplayName("updateFirstName – non-existent contact throws")
    public void testUpdateFirstNameContactNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateFirstName("9999999999", "Jane"));
    }

    // -----------------------------------------------------------------------
    // updateLastName
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("updateLastName – success path")
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updateLastName("1234567890", "Smith"));
        assertEquals("Smith", contactService.getContact("1234567890").getLastName());
    }

    @Test
    @DisplayName("updateLastName – non-existent contact throws")
    public void testUpdateLastNameContactNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateLastName("9999999999", "Smith"));
    }

    @Test
    @DisplayName("updateLastName – null value rejected")
    public void testUpdateLastNameNull() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateLastName("1234567890", null));
    }

    // -----------------------------------------------------------------------
    // updatePhone
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("updatePhone – success path")
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updatePhone("1234567890", "9876543210"));
        assertEquals("9876543210", contactService.getContact("1234567890").getPhone());
    }

    @Test
    @DisplayName("updatePhone – fewer than 10 digits rejected")
    public void testUpdatePhoneTooShort() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updatePhone("1234567890", "123"));
    }

    @Test
    @DisplayName("updatePhone – non-numeric string rejected")
    public void testUpdatePhoneNonNumeric() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updatePhone("1234567890", "12345ABCDE"));
    }

    @Test
    @DisplayName("updatePhone – non-existent contact throws")
    public void testUpdatePhoneContactNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updatePhone("9999999999", "9876543210"));
    }

    // -----------------------------------------------------------------------
    // updateAddress
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("updateAddress – success path")
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updateAddress("1234567890", "456 Oak Ave"));
        assertEquals("456 Oak Ave", contactService.getContact("1234567890").getAddress());
    }

    @Test
    @DisplayName("updateAddress – boundary: exactly 30 characters accepted")
    public void testUpdateAddressBoundaryAccepted() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updateAddress("1234567890", "123456789012345678901234567890")); // 30 chars
    }

    @Test
    @DisplayName("updateAddress – 31 characters rejected")
    public void testUpdateAddressTooLong() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateAddress("1234567890",
                        "1234567890123456789012345678901")); // 31 chars
    }

    @Test
    @DisplayName("updateAddress – non-existent contact throws")
    public void testUpdateAddressContactNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateAddress("9999999999", "456 Oak Ave"));
    }

    // -----------------------------------------------------------------------
    // Multiple contacts
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Multiple contacts can coexist independently")
    public void testMultipleContacts() {
        Contact c1 = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        Contact c2 = new Contact("0987654321", "Jane", "Smith", "9876543210", "456 Oak Ave");
        contactService.addContact(c1);
        contactService.addContact(c2);
        assertEquals(c1, contactService.getContact("1234567890"));
        assertEquals(c2, contactService.getContact("0987654321"));
    }
}
