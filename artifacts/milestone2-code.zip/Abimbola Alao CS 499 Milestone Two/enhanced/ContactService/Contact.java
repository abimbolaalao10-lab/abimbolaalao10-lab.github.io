/**
 * Represents a contact in the contact management system.
 *
 * <p>A {@code Contact} is immutable with respect to its ID and enforces field-level
 * validation on all mutable fields. Once constructed with a valid state, the object
 * cannot be placed into an invalid state through its public API.</p>
 *
 * <p>Validation rules:</p>
 * <ul>
 *   <li>{@code contactId}  – non-null, 1–10 characters, immutable after construction</li>
 *   <li>{@code firstName}  – non-null, 1–10 characters</li>
 *   <li>{@code lastName}   – non-null, 1–10 characters</li>
 *   <li>{@code phone}      – non-null, exactly 10 numeric digits</li>
 *   <li>{@code address}    – non-null, 1–30 characters</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public class Contact {

    /** Unique, immutable identifier for this contact. */
    private final String contactId;

    /** Contact's first name. */
    private String firstName;

    /** Contact's last name. */
    private String lastName;

    /** Contact's 10-digit phone number (digits only). */
    private String phone;

    /** Contact's mailing address. */
    private String address;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a fully validated {@code Contact}.
     *
     * @param contactId unique identifier; non-null, max 10 characters
     * @param firstName first name; non-null, max 10 characters
     * @param lastName  last name; non-null, max 10 characters
     * @param phone     10-digit numeric phone number; non-null, exactly 10 digits
     * @param address   mailing address; non-null, max 30 characters
     * @throws IllegalArgumentException if any argument fails its validation rule
     */
    public Contact(String contactId, String firstName, String lastName,
                   String phone, String address) {

        if (contactId == null || contactId.isEmpty() || contactId.length() > 10) {
            throw new IllegalArgumentException(
                    "Contact ID must be non-null and between 1–10 characters.");
        }
        if (firstName == null || firstName.isEmpty() || firstName.length() > 10) {
            throw new IllegalArgumentException(
                    "First name must be non-null and between 1–10 characters.");
        }
        if (lastName == null || lastName.isEmpty() || lastName.length() > 10) {
            throw new IllegalArgumentException(
                    "Last name must be non-null and between 1–10 characters.");
        }
        if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
            throw new IllegalArgumentException(
                    "Phone must be non-null and exactly 10 numeric digits.");
        }
        if (address == null || address.isEmpty() || address.length() > 30) {
            throw new IllegalArgumentException(
                    "Address must be non-null and between 1–30 characters.");
        }

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName  = lastName;
        this.phone     = phone;
        this.address   = address;
    }

    // -----------------------------------------------------------------------
    // Getters
    // -----------------------------------------------------------------------

    /**
     * Returns the contact's unique, immutable identifier.
     *
     * @return the contact ID; never {@code null}
     */
    public String getContactId() { return contactId; }

    /**
     * Returns the contact's first name.
     *
     * @return the first name; never {@code null}
     */
    public String getFirstName() { return firstName; }

    /**
     * Returns the contact's last name.
     *
     * @return the last name; never {@code null}
     */
    public String getLastName() { return lastName; }

    /**
     * Returns the contact's phone number (10 digits, no formatting).
     *
     * @return the phone number; never {@code null}
     */
    public String getPhone() { return phone; }

    /**
     * Returns the contact's mailing address.
     *
     * @return the address; never {@code null}
     */
    public String getAddress() { return address; }

    // -----------------------------------------------------------------------
    // Setters
    // -----------------------------------------------------------------------

    /**
     * Updates the contact's first name.
     *
     * @param firstName the new first name; non-null, max 10 characters
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.isEmpty() || firstName.length() > 10) {
            throw new IllegalArgumentException(
                    "First name must be non-null and between 1–10 characters.");
        }
        this.firstName = firstName;
    }

    /**
     * Updates the contact's last name.
     *
     * @param lastName the new last name; non-null, max 10 characters
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.isEmpty() || lastName.length() > 10) {
            throw new IllegalArgumentException(
                    "Last name must be non-null and between 1–10 characters.");
        }
        this.lastName = lastName;
    }

    /**
     * Updates the contact's phone number.
     *
     * @param phone the new phone number; non-null, exactly 10 numeric digits
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
            throw new IllegalArgumentException(
                    "Phone must be non-null and exactly 10 numeric digits.");
        }
        this.phone = phone;
    }

    /**
     * Updates the contact's mailing address.
     *
     * @param address the new address; non-null, max 30 characters
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setAddress(String address) {
        if (address == null || address.isEmpty() || address.length() > 30) {
            throw new IllegalArgumentException(
                    "Address must be non-null and between 1–30 characters.");
        }
        this.address = address;
    }
}
