/**
 * IContactService defines the public contract for any contact management service.
 *
 * <p>By programming to this interface rather than a concrete implementation,
 * callers remain decoupled from storage details and the implementation can be
 * swapped (e.g. in-memory HashMap vs. a database-backed service) without
 * changing any calling code.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public interface IContactService {

    /**
     * Adds a new contact to the service.
     *
     * @param contact the {@link Contact} to add; must not be {@code null}
     * @return {@code true} if the contact was successfully added
     * @throws IllegalArgumentException if the contact is {@code null} or if a
     *                                  contact with the same ID already exists
     */
    boolean addContact(Contact contact);

    /**
     * Deletes the contact identified by the given ID.
     *
     * @param contactId the unique identifier of the contact to remove;
     *                  must not be {@code null}
     * @return {@code true} if the contact was successfully removed
     * @throws IllegalArgumentException if {@code contactId} is {@code null} or
     *                                  no contact with that ID exists
     */
    boolean deleteContact(String contactId);

    /**
     * Updates the first name of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param firstName the new first name; must satisfy {@link Contact} validation rules
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or the value is invalid
     */
    boolean updateFirstName(String contactId, String firstName);

    /**
     * Updates the last name of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param lastName  the new last name; must satisfy {@link Contact} validation rules
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or the value is invalid
     */
    boolean updateLastName(String contactId, String lastName);

    /**
     * Updates the phone number of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param phone     the new 10-digit phone number
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or the value is invalid
     */
    boolean updatePhone(String contactId, String phone);

    /**
     * Updates the address of an existing contact.
     *
     * @param contactId the unique identifier of the contact to update
     * @param address   the new address; must satisfy {@link Contact} validation rules
     * @return {@code true} if the update was successful
     * @throws IllegalArgumentException if the contact is not found or the value is invalid
     */
    boolean updateAddress(String contactId, String address);

    /**
     * Retrieves the contact with the given ID.
     *
     * @param contactId the unique identifier to look up
     * @return the matching {@link Contact}, or {@code null} if not found
     */
    Contact getContact(String contactId);
}
