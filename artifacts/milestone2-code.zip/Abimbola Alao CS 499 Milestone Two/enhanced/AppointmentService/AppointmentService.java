import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * In-memory implementation of {@link IAppointmentService}.
 *
 * <p>Appointments are stored in a {@link HashMap} keyed by appointment ID,
 * giving O(1) average-case performance for all CRUD operations.</p>
 *
 * <p>Key improvements over the original implementation:</p>
 * <ul>
 *   <li>Implements {@link IAppointmentService} — callers depend on the interface,
 *       not the concrete class.</li>
 *   <li>All operations are logged via the Java logging framework.</li>
 *   <li>{@code deleteAppointment} now validates the ID before removing,
 *       consistent with the other service classes.</li>
 *   <li>New {@code updateAppointmentDate} and {@code updateAppointmentDescription}
 *       methods complete the CRUD surface for appointments.</li>
 *   <li>Null-safety enforced consistently across every public method.</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.0
 * @see IAppointmentService
 */
public class AppointmentService implements IAppointmentService {

    /** Logger for this class. */
    private static final Logger LOGGER =
            Logger.getLogger(AppointmentService.class.getName());

    /** Internal storage: appointmentId → Appointment. */
    private final Map<String, Appointment> appointments;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a new, empty {@code AppointmentService}.
     */
    public AppointmentService() {
        this.appointments = new HashMap<>();
        LOGGER.info("AppointmentService initialised.");
    }

    // -----------------------------------------------------------------------
    // IAppointmentService implementation
    // -----------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * @throws IllegalArgumentException if {@code appointment} is {@code null}
     *                                  or an appointment with the same ID already exists
     */
    @Override
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            LOGGER.warning("addAppointment called with null appointment.");
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        String id = appointment.getAppointmentId();

        if (appointments.containsKey(id)) {
            LOGGER.warning("addAppointment failed: duplicate ID '" + id + "'.");
            throw new IllegalArgumentException("Appointment ID already exists: " + id);
        }

        appointments.put(id, appointment);
        LOGGER.info("Appointment added. ID='" + id + "'.");
    }

    /**
     * {@inheritDoc}
     *
     * <p>Unlike the original implementation, this method validates that the ID
     * is non-null and exists before attempting removal. This makes error handling
     * consistent with {@code ContactService} and {@code TaskService}.</p>
     *
     * @throws IllegalArgumentException if {@code appointmentId} is {@code null}
     *                                  or no appointment with that ID exists
     */
    @Override
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            LOGGER.warning("deleteAppointment failed: ID '" + appointmentId + "' not found.");
            throw new IllegalArgumentException("Appointment ID not found: " + appointmentId);
        }

        appointments.remove(appointmentId);
        LOGGER.info("Appointment deleted. ID='" + appointmentId + "'.");
    }

    /**
     * {@inheritDoc}
     *
     * <p>This method was absent in the original implementation. Its addition
     * completes the CRUD surface for the AppointmentService.</p>
     *
     * @throws IllegalArgumentException if the appointment is not found or the
     *                                  date is null / in the past
     */
    @Override
    public void updateAppointmentDate(String appointmentId, Date newDate) {
        Appointment appointment = requireAppointment(appointmentId, "updateAppointmentDate");
        appointment.setAppointmentDate(newDate);
        LOGGER.info("Appointment date updated. ID='" + appointmentId + "'.");
    }

    /**
     * {@inheritDoc}
     *
     * <p>This method was absent in the original implementation. Its addition
     * completes the CRUD surface for the AppointmentService.</p>
     *
     * @throws IllegalArgumentException if the appointment is not found or the
     *                                  description is invalid
     */
    @Override
    public void updateAppointmentDescription(String appointmentId, String description) {
        Appointment appointment = requireAppointment(appointmentId, "updateAppointmentDescription");
        appointment.setDescription(description);
        LOGGER.info("Appointment description updated. ID='" + appointmentId + "'.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Retrieves an appointment or throws an {@link IllegalArgumentException} if
     * the ID does not map to an existing appointment.
     *
     * @param appointmentId the ID to look up
     * @param methodName    the calling method name (for logging)
     * @return the found {@link Appointment}; never {@code null}
     * @throws IllegalArgumentException if the appointment does not exist
     */
    private Appointment requireAppointment(String appointmentId, String methodName) {
        Appointment appointment = appointments.get(appointmentId);
        if (appointment == null) {
            LOGGER.warning(methodName + " failed: ID '" + appointmentId + "' not found.");
            throw new IllegalArgumentException("Appointment ID not found: " + appointmentId);
        }
        return appointment;
    }
}
