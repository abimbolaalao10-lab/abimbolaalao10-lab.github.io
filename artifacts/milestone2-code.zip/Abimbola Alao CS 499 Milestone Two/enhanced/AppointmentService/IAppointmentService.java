import java.util.Date;

/**
 * IAppointmentService defines the public contract for any appointment management service.
 *
 * <p>Callers depend on this interface rather than a concrete class, keeping
 * the system open for extension (e.g. a calendar-integrated implementation)
 * without modifying existing clients.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public interface IAppointmentService {

    /**
     * Adds a new appointment to the service.
     *
     * @param appointment the {@link Appointment} to add; must not be {@code null}
     * @throws IllegalArgumentException if the appointment is {@code null} or an
     *                                  appointment with the same ID already exists
     */
    void addAppointment(Appointment appointment);

    /**
     * Deletes the appointment identified by the given ID.
     *
     * @param appointmentId the unique identifier of the appointment to remove;
     *                      must not be {@code null}
     * @throws IllegalArgumentException if {@code appointmentId} is {@code null}
     *                                  or no appointment with that ID exists
     */
    void deleteAppointment(String appointmentId);

    /**
     * Updates the date of an existing appointment.
     *
     * @param appointmentId the unique identifier of the appointment to update
     * @param newDate       the new appointment date; must be a future date
     * @throws IllegalArgumentException if the appointment is not found or the date is invalid
     */
    void updateAppointmentDate(String appointmentId, Date newDate);

    /**
     * Updates the description of an existing appointment.
     *
     * @param appointmentId the unique identifier of the appointment to update
     * @param description   the new description; must satisfy {@link Appointment} validation rules
     * @throws IllegalArgumentException if the appointment is not found or the value is invalid
     */
    void updateAppointmentDescription(String appointmentId, String description);

    /**
     * Retrieves the appointment with the given ID.
     *
     * @param appointmentId the unique identifier to look up
     * @return the matching {@link Appointment}, or {@code null} if not found
     */
    Appointment getAppointment(String appointmentId);
}
