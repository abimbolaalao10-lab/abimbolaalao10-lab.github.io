import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Date;

/**
 * Unit tests for {@link AppointmentService}.
 *
 * <p>Coverage includes happy-path CRUD, null input rejection,
 * duplicate ID detection, and the new update methods added in v2.0.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public class AppointmentServiceTest {

    private IAppointmentService service;
    private Date futureDate;
    private Date farFutureDate;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        futureDate    = new Date(System.currentTimeMillis() + 3_600_000L);       // +1 hour
        farFutureDate = new Date(System.currentTimeMillis() + 7_200_000L);       // +2 hours
    }

    @Test
    @DisplayName("addAppointment – success path")
    void testAddAppointment() {
        Appointment appt = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appt);
        assertNotNull(service.getAppointment("1"));
    }

    @Test
    @DisplayName("addAppointment – null appointment throws")
    void testAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    @DisplayName("addAppointment – duplicate ID throws")
    void testAddDuplicateAppointmentId() {
        Appointment a1 = new Appointment("1", futureDate, "Meeting 1");
        Appointment a2 = new Appointment("1", futureDate, "Meeting 2");
        service.addAppointment(a1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(a2));
    }

    @Test
    @DisplayName("deleteAppointment – success path")
    void testDeleteAppointment() {
        Appointment appt = new Appointment("2", futureDate, "Call");
        service.addAppointment(appt);
        service.deleteAppointment("2");
        assertNull(service.getAppointment("2"));
    }

    @Test
    @DisplayName("deleteAppointment – null ID throws")
    void testDeleteAppointmentNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }

    @Test
    @DisplayName("deleteAppointment – non-existent ID throws")
    void testDeleteAppointmentNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteAppointment("9999999999"));
    }

    @Test
    @DisplayName("updateAppointmentDate – success path")
    void testUpdateAppointmentDate() {
        Appointment appt = new Appointment("3", futureDate, "Review");
        service.addAppointment(appt);
        service.updateAppointmentDate("3", farFutureDate);
        assertEquals(farFutureDate, service.getAppointment("3").getAppointmentDate());
    }

    @Test
    @DisplayName("updateAppointmentDate – past date rejected")
    void testUpdateAppointmentDatePast() {
        Appointment appt = new Appointment("3", futureDate, "Review");
        service.addAppointment(appt);
        Date pastDate = new Date(System.currentTimeMillis() - 3_600_000L);
        assertThrows(IllegalArgumentException.class,
                () -> service.updateAppointmentDate("3", pastDate));
    }

    @Test
    @DisplayName("updateAppointmentDate – null date rejected")
    void testUpdateAppointmentDateNull() {
        Appointment appt = new Appointment("3", futureDate, "Review");
        service.addAppointment(appt);
        assertThrows(IllegalArgumentException.class,
                () -> service.updateAppointmentDate("3", null));
    }

    @Test
    @DisplayName("updateAppointmentDate – non-existent ID throws")
    void testUpdateAppointmentDateNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> service.updateAppointmentDate("9999", farFutureDate));
    }

    @Test
    @DisplayName("updateAppointmentDescription – success path")
    void testUpdateAppointmentDescription() {
        Appointment appt = new Appointment("4", futureDate, "Old Desc");
        service.addAppointment(appt);
        service.updateAppointmentDescription("4", "New Desc");
        assertEquals("New Desc", service.getAppointment("4").getDescription());
    }

    @Test
    @DisplayName("updateAppointmentDescription – null value rejected")
    void testUpdateAppointmentDescriptionNull() {
        Appointment appt = new Appointment("4", futureDate, "Old Desc");
        service.addAppointment(appt);
        assertThrows(IllegalArgumentException.class,
                () -> service.updateAppointmentDescription("4", null));
    }

    @Test
    @DisplayName("updateAppointmentDescription – non-existent ID throws")
    void testUpdateAppointmentDescriptionNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> service.updateAppointmentDescription("9999", "New Desc"));
    }
}
