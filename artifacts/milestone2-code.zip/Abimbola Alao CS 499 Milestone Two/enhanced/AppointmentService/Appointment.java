import java.util.Date;

/**
 * Represents a scheduled appointment in the appointment management system.
 *
 * <p>An {@code Appointment} enforces field-level validation on all mutable
 * fields. Once constructed with valid data the object cannot be placed into
 * an invalid state through its public API.</p>
 *
 * <p>Validation rules:</p>
 * <ul>
 *   <li>{@code appointmentId}   – non-null, 1–10 characters, immutable after construction</li>
 *   <li>{@code appointmentDate} – non-null, must be a future date</li>
 *   <li>{@code description}     – non-null, 1–50 characters</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public class Appointment {

    /** Unique, immutable identifier for this appointment. */
    private final String appointmentId;

    /** Scheduled date and time of the appointment (must be in the future). */
    private Date appointmentDate;

    /** Human-readable description of the appointment. */
    private String description;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a fully validated {@code Appointment}.
     *
     * @param appointmentId   unique identifier; non-null, max 10 characters
     * @param appointmentDate scheduled date; non-null, must be a future date
     * @param description     appointment description; non-null, max 50 characters
     * @throws IllegalArgumentException if any argument fails its validation rule
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.isEmpty() || appointmentId.length() > 10) {
            throw new IllegalArgumentException(
                    "Appointment ID must be non-null and between 1–10 characters.");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException(
                    "Appointment date must be non-null and in the future.");
        }
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Description must be non-null and between 1–50 characters.");
        }

        this.appointmentId   = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description     = description;
    }

    // -----------------------------------------------------------------------
    // Getters
    // -----------------------------------------------------------------------

    /**
     * Returns the appointment's unique, immutable identifier.
     *
     * @return the appointment ID; never {@code null}
     */
    public String getAppointmentId() { return appointmentId; }

    /**
     * Returns the scheduled date and time of the appointment.
     *
     * @return the appointment date; never {@code null}
     */
    public Date getAppointmentDate() { return appointmentDate; }

    /**
     * Returns the appointment description.
     *
     * @return the description; never {@code null}
     */
    public String getDescription() { return description; }

    // -----------------------------------------------------------------------
    // Setters
    // -----------------------------------------------------------------------

    /**
     * Updates the scheduled date of this appointment.
     *
     * @param appointmentDate the new date; must be non-null and in the future
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException(
                    "Appointment date must be non-null and in the future.");
        }
        this.appointmentDate = appointmentDate;
    }

    /**
     * Updates the appointment description.
     *
     * @param description the new description; non-null, max 50 characters
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Description must be non-null and between 1–50 characters.");
        }
        this.description = description;
    }
}
