import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link TaskService}.
 *
 * <p>Coverage includes happy-path CRUD, null input rejection,
 * boundary values, and duplicate ID detection.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public class TaskServiceTest {

    private ITaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
    }

    @Test
    @DisplayName("addTask – success path")
    void testAddTask() {
        Task task = new Task("1", "Task One", "Description One");
        taskService.addTask(task);
        assertNotNull(taskService.getTask("1"));
    }

    @Test
    @DisplayName("addTask – null task throws")
    void testAddNullTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(null));
    }

    @Test
    @DisplayName("addTask – duplicate ID throws")
    void testAddDuplicateTaskId() {
        Task t1 = new Task("1", "Task One", "Description One");
        Task t2 = new Task("1", "Task Two", "Description Two");
        taskService.addTask(t1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(t2));
    }

    @Test
    @DisplayName("deleteTask – success path")
    void testDeleteTask() {
        Task task = new Task("2", "Task", "Description");
        taskService.addTask(task);
        taskService.deleteTask("2");
        assertNull(taskService.getTask("2"));
    }

    @Test
    @DisplayName("deleteTask – null ID throws")
    void testDeleteTaskNullId() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask(null));
    }

    @Test
    @DisplayName("deleteTask – non-existent ID throws")
    void testDeleteTaskNotFound() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("9999999999"));
    }

    @Test
    @DisplayName("updateTaskName – success path")
    void testUpdateTaskName() {
        Task task = new Task("3", "Old Name", "Description");
        taskService.addTask(task);
        taskService.updateTaskName("3", "New Name");
        assertEquals("New Name", taskService.getTask("3").getName());
    }

    @Test
    @DisplayName("updateTaskName – boundary: exactly 20 characters accepted")
    void testUpdateTaskNameBoundary() {
        Task task = new Task("3", "Old Name", "Description");
        taskService.addTask(task);
        taskService.updateTaskName("3", "12345678901234567890"); // 20 chars
        assertEquals("12345678901234567890", taskService.getTask("3").getName());
    }

    @Test
    @DisplayName("updateTaskName – 21 characters rejected")
    void testUpdateTaskNameTooLong() {
        Task task = new Task("3", "Old Name", "Description");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class,
                () -> taskService.updateTaskName("3", "123456789012345678901")); // 21 chars
    }

    @Test
    @DisplayName("updateTaskName – null value rejected")
    void testUpdateTaskNameNull() {
        Task task = new Task("3", "Old Name", "Description");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class,
                () -> taskService.updateTaskName("3", null));
    }

    @Test
    @DisplayName("updateTaskDescription – success path")
    void testUpdateTaskDescription() {
        Task task = new Task("4", "Task", "Old Description");
        taskService.addTask(task);
        taskService.updateTaskDescription("4", "New Description");
        assertEquals("New Description", taskService.getTask("4").getDescription());
    }

    @Test
    @DisplayName("updateTaskDescription – null value rejected")
    void testUpdateTaskDescriptionNull() {
        Task task = new Task("4", "Task", "Old Description");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class,
                () -> taskService.updateTaskDescription("4", null));
    }

    @Test
    @DisplayName("updateTaskDescription – non-existent task throws")
    void testUpdateTaskDescriptionNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> taskService.updateTaskDescription("9999", "New Desc"));
    }
}
