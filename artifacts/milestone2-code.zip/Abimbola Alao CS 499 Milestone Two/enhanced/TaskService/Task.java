/**
 * Represents a task in the task management system.
 *
 * <p>A {@code Task} enforces field-level validation on all mutable fields.
 * Once constructed with valid data the object cannot be placed into an
 * invalid state through its public API.</p>
 *
 * <p>Validation rules:</p>
 * <ul>
 *   <li>{@code taskId}      – non-null, 1–10 characters, immutable after construction</li>
 *   <li>{@code name}        – non-null, 1–20 characters</li>
 *   <li>{@code description} – non-null, 1–50 characters</li>
 * </ul>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public class Task {

    /** Unique, immutable identifier for this task. */
    private final String taskId;

    /** Short human-readable name for the task. */
    private String name;

    /** Longer description of what the task entails. */
    private String description;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a fully validated {@code Task}.
     *
     * @param taskId      unique identifier; non-null, max 10 characters
     * @param name        task name; non-null, max 20 characters
     * @param description task description; non-null, max 50 characters
     * @throws IllegalArgumentException if any argument fails its validation rule
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.isEmpty() || taskId.length() > 10) {
            throw new IllegalArgumentException(
                    "Task ID must be non-null and between 1–10 characters.");
        }
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException(
                    "Task name must be non-null and between 1–20 characters.");
        }
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Task description must be non-null and between 1–50 characters.");
        }

        this.taskId      = taskId;
        this.name        = name;
        this.description = description;
    }

    // -----------------------------------------------------------------------
    // Getters
    // -----------------------------------------------------------------------

    /**
     * Returns the task's unique, immutable identifier.
     *
     * @return the task ID; never {@code null}
     */
    public String getTaskId() { return taskId; }

    /**
     * Returns the task's name.
     *
     * @return the name; never {@code null}
     */
    public String getName() { return name; }

    /**
     * Returns the task's description.
     *
     * @return the description; never {@code null}
     */
    public String getDescription() { return description; }

    // -----------------------------------------------------------------------
    // Setters
    // -----------------------------------------------------------------------

    /**
     * Updates the task's name.
     *
     * @param name the new name; non-null, max 20 characters
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setName(String name) {
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException(
                    "Task name must be non-null and between 1–20 characters.");
        }
        this.name = name;
    }

    /**
     * Updates the task's description.
     *
     * @param description the new description; non-null, max 50 characters
     * @throws IllegalArgumentException if the value fails validation
     */
    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Task description must be non-null and between 1–50 characters.");
        }
        this.description = description;
    }
}
