/**
 * ITaskService defines the public contract for any task management service.
 *
 * <p>Programming to this interface decouples callers from the concrete storage
 * implementation, enabling easy substitution of in-memory, file-based, or
 * database-backed implementations without changing client code.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 */
public interface ITaskService {

    /**
     * Adds a new task to the service.
     *
     * @param task the {@link Task} to add; must not be {@code null}
     * @throws IllegalArgumentException if the task is {@code null} or a task
     *                                  with the same ID already exists
     */
    void addTask(Task task);

    /**
     * Deletes the task identified by the given ID.
     *
     * @param taskId the unique identifier of the task to remove; must not be {@code null}
     * @throws IllegalArgumentException if {@code taskId} is {@code null} or
     *                                  no task with that ID exists
     */
    void deleteTask(String taskId);

    /**
     * Updates the name of an existing task.
     *
     * @param taskId the unique identifier of the task to update
     * @param name   the new task name; must satisfy {@link Task} validation rules
     * @throws IllegalArgumentException if the task is not found or the value is invalid
     */
    void updateTaskName(String taskId, String name);

    /**
     * Updates the description of an existing task.
     *
     * @param taskId      the unique identifier of the task to update
     * @param description the new description; must satisfy {@link Task} validation rules
     * @throws IllegalArgumentException if the task is not found or the value is invalid
     */
    void updateTaskDescription(String taskId, String description);

    /**
     * Retrieves the task with the given ID.
     *
     * @param taskId the unique identifier to look up
     * @return the matching {@link Task}, or {@code null} if not found
     */
    Task getTask(String taskId);
}
