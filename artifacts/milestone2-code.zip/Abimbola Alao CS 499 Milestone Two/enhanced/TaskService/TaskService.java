import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * In-memory implementation of {@link ITaskService}.
 *
 * <p>Tasks are stored in a {@link HashMap} keyed by task ID, giving O(1)
 * average-case performance for all CRUD operations.</p>
 *
 * <p>All operations are logged through the Java logging framework.
 * Validation failures produce {@code WARNING}-level log entries; successful
 * mutations produce {@code INFO}-level entries.</p>
 *
 * @author Abimbola Alao
 * @version 2.0
 * @see ITaskService
 */
public class TaskService implements ITaskService {

    /** Logger for this class. */
    private static final Logger LOGGER =
            Logger.getLogger(TaskService.class.getName());

    /** Internal storage: taskId → Task. */
    private final Map<String, Task> tasks;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a new, empty {@code TaskService}.
     */
    public TaskService() {
        this.tasks = new HashMap<>();
        LOGGER.info("TaskService initialised.");
    }

    // -----------------------------------------------------------------------
    // ITaskService implementation
    // -----------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * @throws IllegalArgumentException if {@code task} is {@code null} or a
     *                                  task with the same ID already exists
     */
    @Override
    public void addTask(Task task) {
        if (task == null) {
            LOGGER.warning("addTask called with null task.");
            throw new IllegalArgumentException("Task cannot be null.");
        }

        String id = task.getTaskId();

        if (tasks.containsKey(id)) {
            LOGGER.warning("addTask failed: duplicate ID '" + id + "'.");
            throw new IllegalArgumentException("Task ID already exists: " + id);
        }

        tasks.put(id, task);
        LOGGER.info("Task added. ID='" + id + "'.");
    }

    /**
     * {@inheritDoc}
     *
     * @throws IllegalArgumentException if {@code taskId} is {@code null} or
     *                                  no task with that ID exists
     */
    @Override
    public void deleteTask(String taskId) {
        if (taskId == null || !tasks.containsKey(taskId)) {
            LOGGER.warning("deleteTask failed: ID '" + taskId + "' not found.");
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }

        tasks.remove(taskId);
        LOGGER.info("Task deleted. ID='" + taskId + "'.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void updateTaskName(String taskId, String name) {
        Task task = requireTask(taskId, "updateTaskName");
        task.setName(name);
        LOGGER.info("Task name updated. ID='" + taskId + "'.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void updateTaskDescription(String taskId, String description) {
        Task task = requireTask(taskId, "updateTaskDescription");
        task.setDescription(description);
        LOGGER.info("Task description updated. ID='" + taskId + "'.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Retrieves a task or throws an {@link IllegalArgumentException} with a
     * consistent message if the ID does not map to an existing task.
     *
     * @param taskId     the ID to look up
     * @param methodName the calling method name (for logging)
     * @return the found {@link Task}; never {@code null}
     * @throws IllegalArgumentException if the task does not exist
     */
    private Task requireTask(String taskId, String methodName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            LOGGER.warning(methodName + " failed: task ID '" + taskId + "' not found.");
            throw new IllegalArgumentException("Task not found: " + taskId);
        }
        return task;
    }
}
