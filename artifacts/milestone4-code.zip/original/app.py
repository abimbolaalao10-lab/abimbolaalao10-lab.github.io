"""
Phishing Email Detection Web Application
==========================================
AI-Powered Phishing Email Detector using Random Forest (99.74% Accuracy)

This web application provides an easy-to-use interface for detecting phishing emails.
Simply paste any email text and get instant predictions with confidence scores.
"""

import gradio as gr
import joblib
import pandas as pd
import numpy as np
import re
from pathlib import Path
import spacy
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer

# Load spaCy model
try:
    nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])
except:
    print("Downloading spaCy model...")
    import os
    os.system('python -m spacy download en_core_web_sm')
    nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])

# Load the trained model
MODEL_PATH = Path('models/best_model.pkl')
if not MODEL_PATH.exists():
    raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Please run training first.")

model = joblib.load(MODEL_PATH)
print(f"Loaded model: {MODEL_PATH}")

# Load the saved TF-IDF vectorizer
TFIDF_PATH = Path('models/tfidf_vectorizer.pkl')
if TFIDF_PATH.exists():
    tfidf_vectorizer = joblib.load(TFIDF_PATH)
    print(f"Loaded TF-IDF vectorizer: {TFIDF_PATH}")
else:
    print("Warning: TF-IDF vectorizer not found.")
    tfidf_vectorizer = None

# Load feature names
FEATURE_NAMES_PATH = Path('models/feature_names.pkl')
if FEATURE_NAMES_PATH.exists():
    feature_names = joblib.load(FEATURE_NAMES_PATH)
    print(f"Loaded {len(feature_names)} feature names")
else:
    print("Warning: Feature names not found")
    feature_names = None


class EmailPreprocessor:
    """Preprocess email text for prediction - matches training pipeline exactly"""

    def remove_html_tags(self, text):
        """Remove HTML tags using BeautifulSoup - same as training"""
        if not text:
            return ""
        soup = BeautifulSoup(text, 'html.parser')
        return soup.get_text()

    def extract_urls(self, text):
        """Extract all URLs from text - same as training"""
        if not text:
            return []
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        return re.findall(url_pattern, text)

    def clean_text(self, text):
        """Clean text - matches preprocessing.py exactly"""
        if not text:
            return ""
        text = self.remove_html_tags(text)
        text = re.sub(r'http[s]?://\S+', ' ', text)       # remove URLs
        text = re.sub(r'\S+@\S+', ' ', text)               # remove email addresses
        text = text.lower()
        text = re.sub(r'[^a-zA-Z\s]', '', text)            # remove special chars/digits
        text = re.sub(r'\s+', ' ', text).strip()           # normalize whitespace
        return text

    def apply_nlp(self, text):
        """Apply spaCy NLP - matches preprocessing.py exactly"""
        if not text:
            return ""
        text = text[:100000]  # same limit as training
        doc = nlp(text)
        tokens = [
            token.lemma_ for token in doc
            if not token.is_stop and not token.is_punct and len(token.text) > 2
        ]
        return ' '.join(tokens)

    def parse_subject_body(self, email_text):
        """Extract subject and body separately - matches training data structure"""
        subject = ""
        body = email_text

        lines = email_text.split('\n')
        for i, line in enumerate(lines):
            if line.lower().startswith('subject:'):
                subject = line.split(':', 1)[1].strip()
                body = '\n'.join(lines[i+1:]).strip()
                break

        return subject, body

    def preprocess(self, email_text):
        """Full preprocessing pipeline matching training exactly"""
        # Split subject and body
        subject, body = self.parse_subject_body(email_text)

        # Extract URLs from raw body before cleaning
        urls = self.extract_urls(body)

        # Clean and apply NLP to subject and body separately
        subject_clean = self.apply_nlp(self.clean_text(subject))
        body_clean = self.apply_nlp(self.clean_text(body))

        # Combined text for TF-IDF (same as training: subject_clean + body_clean)
        combined_text = f"{subject_clean} {body_clean}".strip()

        return subject, body, subject_clean, body_clean, combined_text, urls


class FeatureExtractor:
    """Extract features matching feature_extraction.py exactly"""

    def extract_features(self, email_text, subject, body, subject_clean, body_clean, urls):
        """Extract all features using same logic as training"""
        features = {}

        # -- Structural features --
        features['body_length'] = len(body)
        features['body_clean_length'] = len(body_clean)
        features['subject_length'] = len(subject)
        features['subject_clean_length'] = len(subject_clean)
        features['body_word_count'] = len(body_clean.split()) if body_clean else 0
        features['subject_word_count'] = len(subject_clean.split()) if subject_clean else 0
        features['total_word_count'] = features['body_word_count'] + features['subject_word_count']

        words = body_clean.split()
        features['avg_word_length'] = np.mean([len(w) for w in words]) if words else 0

        # -- URL features --
        features['num_urls'] = len(urls)
        features['has_url'] = 1 if len(urls) > 0 else 0
        suspicious_patterns = ['bit.ly', 'tinyurl', 'goo.gl', 'ow.ly', 'short', 'redirect']
        features['has_suspicious_url'] = 1 if any(p in str(urls).lower() for p in suspicious_patterns) else 0

        # -- Linguistic features (computed on raw body - same as training) --
        features['num_uppercase'] = sum(1 for c in body if c.isupper())
        features['num_lowercase'] = sum(1 for c in body if c.islower())
        features['num_digits'] = sum(1 for c in body if c.isdigit())
        features['num_special_chars'] = sum(1 for c in body if not c.isalnum() and not c.isspace())
        features['num_exclamation'] = body.count('!')
        features['num_question'] = body.count('?')
        features['num_dots'] = body.count('.')

        total_letters = features['num_uppercase'] + features['num_lowercase']
        features['uppercase_ratio'] = features['num_uppercase'] / total_letters if total_letters > 0 else 0

        body_lower = body.lower()

        urgency_pattern = r'\b(urgent|immediate|action required|verify|suspended|limited time|act now|click here|confirm|update)\b'
        features['has_urgency'] = 1 if re.search(urgency_pattern, body_lower) else 0

        financial_words = [
            'bank', 'account', 'payment', 'credit card', 'paypal', 'transaction',
            'money', 'dollar', 'refund', 'invoice', 'bill', 'tax'
        ]
        features['has_financial'] = 1 if any(w in body_lower for w in financial_words) else 0

        security_words = [
            'password', 'security', 'login', 'username', 'verify', 'authenticate',
            'credentials', 'access', 'blocked', 'locked'
        ]
        features['has_security'] = 1 if any(w in body_lower for w in security_words) else 0

        # -- Sender features --
        # No sender info available in app - use least biased defaults
        features['suspicious_sender'] = 0
        features['sender_missing'] = 1

        return features


def predict_phishing(email_text):
    """Main prediction function"""
    global tfidf_vectorizer

    if not email_text or len(email_text.strip()) == 0:
        return "Error", "Please enter some email text", ""

    try:
        # Load TF-IDF vectorizer if not already loaded
        if tfidf_vectorizer is None:
            tfidf_path = Path('models/tfidf_vectorizer.pkl')
            if tfidf_path.exists():
                tfidf_vectorizer = joblib.load(tfidf_path)
                print("Loaded TF-IDF vectorizer")
            else:
                return "Error", "TF-IDF vectorizer not found", "Please run: python src/feature_extraction.py"

        # Preprocess - now matches training pipeline exactly
        preprocessor = EmailPreprocessor()
        subject, body, subject_clean, body_clean, combined_text, urls = preprocessor.preprocess(email_text)

        # Extract features - now matches training pipeline exactly
        extractor = FeatureExtractor()
        features = extractor.extract_features(email_text, subject, body, subject_clean, body_clean, urls)

        # Get TF-IDF features using the saved vectorizer
        tfidf_matrix = tfidf_vectorizer.transform([combined_text])

        # Build TF-IDF DataFrame
        tfidf_feature_names = [f'tfidf_{name}' for name in tfidf_vectorizer.get_feature_names_out()]
        tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), columns=tfidf_feature_names)

        # Build hand-crafted features DataFrame
        hand_crafted_data = {
            'body_length':          [features['body_length']],
            'body_clean_length':    [features['body_clean_length']],
            'subject_length':       [features['subject_length']],
            'subject_clean_length': [features['subject_clean_length']],
            'body_word_count':      [features['body_word_count']],
            'subject_word_count':   [features['subject_word_count']],
            'total_word_count':     [features['total_word_count']],
            'avg_word_length':      [features['avg_word_length']],
            'num_urls':             [features['num_urls']],
            'has_url':              [features['has_url']],
            'has_suspicious_url':   [features['has_suspicious_url']],
            'num_uppercase':        [features['num_uppercase']],
            'num_lowercase':        [features['num_lowercase']],
            'num_digits':           [features['num_digits']],
            'num_special_chars':    [features['num_special_chars']],
            'num_exclamation':      [features['num_exclamation']],
            'num_question':         [features['num_question']],
            'num_dots':             [features['num_dots']],
            'uppercase_ratio':      [features['uppercase_ratio']],
            'has_urgency':          [features['has_urgency']],
            'has_financial':        [features['has_financial']],
            'has_security':         [features['has_security']],
            'suspicious_sender':    [features['suspicious_sender']],
            'sender_missing':       [features['sender_missing']],
        }
        hand_crafted_df = pd.DataFrame(hand_crafted_data)

        # Combine and reorder columns to match training exactly
        X = pd.concat([tfidf_df, hand_crafted_df], axis=1)
        if feature_names is not None:
            X = X[feature_names]

        # Debug info
        print(f"\n=== DEBUG INFO ===")
        print(f"Subject parsed:        '{subject[:60]}'")
        print(f"Body length:           {len(body)}")
        print(f"Combined text:         '{combined_text[:60]}...'")
        print(f"Feature shape:         {X.shape}")
        print(f"TF-IDF non-zero:       {(tfidf_matrix.toarray()[0] > 0).sum()}")
        print(f"subject_length:        {features['subject_length']}")
        print(f"subject_word_count:    {features['subject_word_count']}")
        print(f"has_urgency:           {features['has_urgency']}")
        print(f"suspicious_sender:     {features['suspicious_sender']}")
        print(f"=================\n")

        # Make prediction
        prediction = model.predict(X)[0]
        probability = model.predict_proba(X)[0]
        confidence = probability[prediction] * 100

        print(f"Raw probabilities: ham={probability[0]:.4f}, phishing={probability[1]:.4f}")
        print(f"Prediction: {'Phishing' if prediction == 1 else 'Ham'}")

        # Result label
        result = "PHISHING DETECTED" if prediction == 1 else "LEGITIMATE EMAIL"

        # Build indicators list
        indicators = []
        if features['has_urgency']:
            indicators.append("Urgency keywords detected (urgent, immediate, verify, etc.)")
        if features['has_financial']:
            indicators.append("Financial keywords detected (bank, account, payment, etc.)")
        if features['has_security']:
            indicators.append("Security keywords detected (password, login, authenticate, etc.)")
        if features['uppercase_ratio'] > 0.3:
            indicators.append(f"High uppercase ratio ({features['uppercase_ratio']:.1%}) - possible shouting")
        if features['num_exclamation'] > 3:
            indicators.append(f"Excessive exclamation marks ({features['num_exclamation']})")
        if features['has_suspicious_url']:
            indicators.append("Suspicious shortened URL detected")
        if features['num_urls'] > 5:
            indicators.append(f"High number of URLs ({features['num_urls']})")
        if not indicators:
            indicators.append("No obvious phishing indicators detected")

        return result, f"{confidence:.2f}%", "\n".join(indicators)

    except Exception as e:
        import traceback
        return "Error", f"An error occurred: {str(e)}", traceback.format_exc()


# -- Gradio Interface ----------------------------------------------------------

with gr.Blocks(title="AI Phishing Email Detector", theme=gr.themes.Soft()) as demo:
    gr.Markdown("""
    # AI-Powered Phishing Email Detector

    ### Postgraduate Research Project - 99.74% Accuracy

    This system uses a **Random Forest machine learning model** trained on 10,000 emails to detect phishing attempts.
    Simply paste any email text below to check if it's legitimate or phishing.

    ---
    """)

    with gr.Row():
        with gr.Column():
            email_input = gr.Textbox(
                label="Email Text",
                placeholder="Paste email content here (subject + body)...\n\nExample:\nSubject: Urgent: Your Account Has Been Suspended\n\nDear Customer,\n\nYour account has been temporarily suspended due to unusual activity. Click here to verify your account immediately...",
                lines=12
            )
            predict_btn = gr.Button("Analyze Email", variant="primary", size="lg")

        with gr.Column():
            result_output = gr.Textbox(label="Prediction", lines=1)
            confidence_output = gr.Textbox(label="Confidence Score", lines=1)
            indicators_output = gr.Textbox(label="Detected Indicators", lines=10)

    gr.Markdown("### Try These Examples:")

    examples = [
        ["""Subject: Urgent Account Verification Required

Dear Customer,

Your PayPal account has been temporarily suspended due to unusual activity detected.

To restore full access, please verify your identity immediately by clicking the link below:

http://bit.ly/verify-paypal-account

Failure to verify within 24 hours will result in permanent account closure.

Best regards,
PayPal Security Team"""],

        ["""Subject: Team Meeting Tomorrow

Hi everyone,

Just a reminder that we have our weekly team meeting tomorrow at 2 PM in Conference Room B.

Agenda:
- Q4 project updates
- Budget review
- New hire introductions

Please bring your project status reports.

Thanks,
Sarah"""],

        ["""Subject: URGENT!!! You've Won $1,000,000!!!

CONGRATULATIONS!!!

You have been selected as the GRAND PRIZE WINNER of our international lottery!

CLAIM YOUR $1,000,000 NOW by clicking here: http://tinyurl.com/claim-prize

ACT IMMEDIATELY - This offer expires in 24 HOURS!!!

Click here to verify and receive your winnings!"""]
    ]

    gr.Examples(examples=examples, inputs=email_input, label="Click an example to test:")

    predict_btn.click(
        fn=predict_phishing,
        inputs=email_input,
        outputs=[result_output, confidence_output, indicators_output]
    )

    gr.Markdown("""
    ---

    ### About This System

    **Model:** Random Forest Classifier
    **Training Dataset:** 10,000 emails (5,000 phishing, 5,000 legitimate)
    **Performance:** 99.74% accuracy, 100% precision, 99.48% recall
    **Features:** 3,024 features including TF-IDF, structural, linguistic, and URL analysis

    **Note:** This is a research prototype. For production use, additional security measures and continuous model updates are recommended.
    """)

if __name__ == "__main__":
    print("\n" + "="*60)
    print("LAUNCHING PHISHING EMAIL DETECTOR WEB APP")
    print("="*60)
    print("\nStarting server...")
    print("\n" + "="*60 + "\n")

    demo.launch(
        share=False,
        show_error=True
    )