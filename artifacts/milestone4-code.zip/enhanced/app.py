"""
Phishing Email Detection Web Application
==========================================
AI-Powered Phishing Email Detector using Random Forest (99.74% Accuracy)

Enhancement Three: Database Integration (CS 499 Milestone Four)
----------------------------------------------------------------
This version adds a full SQLite persistence layer to the original stateless
application. Every prediction is now recorded in a structured database and
users can view their full analysis history and submit correction feedback
directly from the interface.

Database schema:
    predictions  — audit log of every email analysis
    feedback     — user-submitted corrections linked to predictions

Security notes:
    - All database queries use parameterized statements to prevent SQL injection
    - The database file path is configurable via the DB_PATH environment variable
    - Email text is truncated to 300 characters before storage to avoid
      persisting full email content unnecessarily (privacy by design)

Author : Abimbola Alao
Version: 2.0 (Milestone Four enhancement)
"""

import gradio as gr
import joblib
import pandas as pd
import numpy as np
import re
import sqlite3
import os
from datetime import datetime
from pathlib import Path

import spacy
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer

# ---------------------------------------------------------------------------
# Database Configuration
# ---------------------------------------------------------------------------

# Allow the database path to be overridden via environment variable.
# Defaulting to a local file keeps the prototype self-contained.
DB_PATH = os.environ.get("PHISHING_DB_PATH", "phishing_detector.db")


def get_connection():
    """
    Create and return a new SQLite connection with foreign key enforcement.

    Foreign key support is disabled by default in SQLite and must be enabled
    per-connection. Enabling it here ensures that every record in the
    feedback table references a valid row in predictions.

    Returns:
        sqlite3.Connection: A configured database connection.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    # Return rows as dictionaries for readable column access
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """
    Initialize the database schema if it does not already exist.

    Two tables are created:

    predictions
        Stores a complete record of every email analysis performed.
        Fields:
            id            – auto-increment primary key
            timestamp     – UTC datetime of analysis (ISO 8601 format)
            email_snippet – first 300 chars of the submitted email (privacy-safe)
            result        – 'PHISHING DETECTED' or 'LEGITIMATE EMAIL'
            confidence    – model confidence score as a percentage string
            indicators    – newline-separated list of detected risk indicators

    feedback
        Stores user-submitted corrections for individual predictions.
        Fields:
            id            – auto-increment primary key
            prediction_id – foreign key → predictions.id (CASCADE on delete)
            timestamp     – UTC datetime of feedback submission
            correct_label – the label the user believes is correct
            comment       – optional free-text explanation from the user

    Both tables use IF NOT EXISTS so this function is safe to call on
    every application startup.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()

        # -- predictions table ------------------------------------------------
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp     TEXT    NOT NULL,
                email_snippet TEXT    NOT NULL,
                result        TEXT    NOT NULL,
                confidence    TEXT    NOT NULL,
                indicators    TEXT    NOT NULL
            )
        """)

        # -- feedback table ---------------------------------------------------
        # ON DELETE CASCADE ensures feedback rows are removed automatically
        # if the parent prediction is ever deleted.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                prediction_id INTEGER NOT NULL
                                REFERENCES predictions(id)
                                ON DELETE CASCADE,
                timestamp     TEXT    NOT NULL,
                correct_label TEXT    NOT NULL,
                comment       TEXT    DEFAULT ''
            )
        """)

        conn.commit()
        print(f"[DB] Database initialised at: {DB_PATH}")
    finally:
        conn.close()


def save_prediction(email_text, result, confidence, indicators):
    """
    Persist an email analysis result to the predictions table.

    Uses a parameterized INSERT statement (? placeholders) to prevent
    SQL injection. The email text is truncated to 300 characters before
    storage so that full email content is not persisted unnecessarily,
    following a privacy-by-design principle.

    Args:
        email_text  (str): The raw email text submitted by the user.
        result      (str): The prediction label ('PHISHING DETECTED' or
                           'LEGITIMATE EMAIL').
        confidence  (str): The formatted confidence percentage string.
        indicators  (str): Newline-separated string of detected indicators.

    Returns:
        int: The auto-generated primary key (id) of the inserted row,
             or None if the insert failed.
    """
    conn = get_connection()
    try:
        # Truncate to 300 characters — store a snippet, not the full email
        snippet = email_text.strip()[:300]
        timestamp = datetime.utcnow().isoformat(sep=" ", timespec="seconds")

        # Parameterized query — no string formatting, no injection risk
        cursor = conn.execute(
            """
            INSERT INTO predictions (timestamp, email_snippet, result, confidence, indicators)
            VALUES (?, ?, ?, ?, ?)
            """,
            (timestamp, snippet, result, confidence, indicators)
        )
        conn.commit()
        prediction_id = cursor.lastrowid
        print(f"[DB] Prediction saved. ID={prediction_id}, result='{result}'")
        return prediction_id
    except sqlite3.Error as e:
        print(f"[DB] ERROR saving prediction: {e}")
        return None
    finally:
        conn.close()


def save_feedback(prediction_id, correct_label, comment=""):
    """
    Persist a user correction to the feedback table.

    Uses parameterized queries throughout. The prediction_id must reference
    a valid row in predictions (enforced by the FOREIGN KEY constraint and
    PRAGMA foreign_keys = ON).

    Args:
        prediction_id (int): The id of the prediction being corrected.
        correct_label (str): The label the user believes is correct.
        comment       (str): Optional free-text explanation.

    Returns:
        bool: True if the feedback was saved successfully, False otherwise.
    """
    if prediction_id is None:
        print("[DB] WARNING: Cannot save feedback — prediction_id is None.")
        return False

    conn = get_connection()
    try:
        timestamp = datetime.utcnow().isoformat(sep=" ", timespec="seconds")

        # Parameterized query — comment from user input must never be
        # interpolated directly into SQL
        conn.execute(
            """
            INSERT INTO feedback (prediction_id, timestamp, correct_label, comment)
            VALUES (?, ?, ?, ?)
            """,
            (prediction_id, timestamp, correct_label, comment)
        )
        conn.commit()
        print(f"[DB] Feedback saved. prediction_id={prediction_id}, label='{correct_label}'")
        return True
    except sqlite3.Error as e:
        print(f"[DB] ERROR saving feedback: {e}")
        return False
    finally:
        conn.close()


def get_recent_predictions(limit=20):
    """
    Retrieve the most recent predictions from the database.

    Uses a parameterized LIMIT clause. Results are ordered by timestamp
    descending so the most recent analysis appears first.

    Args:
        limit (int): Maximum number of rows to return. Defaults to 20.

    Returns:
        list[sqlite3.Row]: List of row objects (accessible as dicts).
                           Returns an empty list if the query fails.
    """
    conn = get_connection()
    try:
        # Parameterized query — limit is a user-controlled value
        cursor = conn.execute(
            """
            SELECT id, timestamp, result, confidence,
                   SUBSTR(email_snippet, 1, 80) AS preview
            FROM   predictions
            ORDER  BY timestamp DESC
            LIMIT  ?
            """,
            (limit,)
        )
        rows = cursor.fetchall()
        return rows
    except sqlite3.Error as e:
        print(f"[DB] ERROR fetching predictions: {e}")
        return []
    finally:
        conn.close()


def format_history_table():
    """
    Build a human-readable string table of recent predictions for display
    in the Gradio history tab.

    Returns:
        str: Formatted table string, or a message if no records exist.
    """
    rows = get_recent_predictions(20)
    if not rows:
        return "No predictions recorded yet. Analyze an email to get started."

    lines = [
        f"{'ID':<5} {'Timestamp':<21} {'Result':<22} {'Confidence':<12} {'Email Preview'}",
        "-" * 100
    ]
    for row in rows:
        lines.append(
            f"{row['id']:<5} {row['timestamp']:<21} {row['result']:<22} "
            f"{row['confidence']:<12} {row['preview']}..."
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# spaCy and Model Loading
# ---------------------------------------------------------------------------

try:
    nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])
except Exception:
    print("Downloading spaCy model...")
    os.system('python -m spacy download en_core_web_sm')
    nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])

MODEL_PATH = Path('models/best_model.pkl')
if not MODEL_PATH.exists():
    raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Please run training first.")

model = joblib.load(MODEL_PATH)
print(f"[MODEL] Loaded: {MODEL_PATH}")

TFIDF_PATH = Path('models/tfidf_vectorizer.pkl')
tfidf_vectorizer = joblib.load(TFIDF_PATH) if TFIDF_PATH.exists() else None
if tfidf_vectorizer:
    print(f"[MODEL] Loaded TF-IDF vectorizer: {TFIDF_PATH}")
else:
    print("[MODEL] WARNING: TF-IDF vectorizer not found.")

FEATURE_NAMES_PATH = Path('models/feature_names.pkl')
feature_names = joblib.load(FEATURE_NAMES_PATH) if FEATURE_NAMES_PATH.exists() else None
if feature_names:
    print(f"[MODEL] Loaded {len(feature_names)} feature names.")


# ---------------------------------------------------------------------------
# Email Preprocessing
# ---------------------------------------------------------------------------

class EmailPreprocessor:
    """
    Preprocess email text for prediction.

    All methods replicate the training pipeline exactly so that the feature
    vectors produced at inference time are consistent with those used during
    model training. Any deviation would silently degrade prediction accuracy.
    """

    def remove_html_tags(self, text):
        """
        Strip HTML markup using BeautifulSoup, matching training preprocessing.

        Args:
            text (str): Raw email text, possibly containing HTML.

        Returns:
            str: Plain text with all HTML tags removed.
        """
        if not text:
            return ""
        soup = BeautifulSoup(text, 'html.parser')
        return soup.get_text()

    def extract_urls(self, text):
        """
        Extract all HTTP/HTTPS URLs from text.

        Args:
            text (str): Raw email body text.

        Returns:
            list[str]: All URLs found; empty list if none.
        """
        if not text:
            return []
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        return re.findall(url_pattern, text)

    def clean_text(self, text):
        """
        Normalize text by stripping HTML, URLs, email addresses, special
        characters, and excess whitespace.

        Matches the clean_text() function in preprocessing.py exactly.

        Args:
            text (str): Raw text to clean.

        Returns:
            str: Cleaned, lowercased text.
        """
        if not text:
            return ""
        text = self.remove_html_tags(text)
        text = re.sub(r'http[s]?://\S+', ' ', text)
        text = re.sub(r'\S+@\S+', ' ', text)
        text = text.lower()
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def apply_nlp(self, text):
        """
        Apply spaCy NLP pipeline: lemmatization and stop-word/punctuation removal.

        Text is capped at 100,000 characters to match the training limit and
        prevent performance issues on unusually long inputs.

        Args:
            text (str): Cleaned text to process.

        Returns:
            str: Space-joined lemmas with stop words and punctuation removed.
        """
        if not text:
            return ""
        text = text[:100000]
        doc = nlp(text)
        tokens = [
            token.lemma_ for token in doc
            if not token.is_stop and not token.is_punct and len(token.text) > 2
        ]
        return ' '.join(tokens)

    def parse_subject_body(self, email_text):
        """
        Split a raw email string into subject and body components.

        Looks for the first line beginning with 'subject:' (case-insensitive).
        If no subject line is found, the full text is treated as the body.

        Args:
            email_text (str): Full raw email text.

        Returns:
            tuple[str, str]: (subject, body)
        """
        subject = ""
        body = email_text
        lines = email_text.split('\n')
        for i, line in enumerate(lines):
            if line.lower().startswith('subject:'):
                subject = line.split(':', 1)[1].strip()
                body = '\n'.join(lines[i + 1:]).strip()
                break
        return subject, body

    def preprocess(self, email_text):
        """
        Run the full preprocessing pipeline on a raw email string.

        Args:
            email_text (str): The raw email text submitted by the user.

        Returns:
            tuple: (subject, body, subject_clean, body_clean,
                    combined_text, urls)
        """
        subject, body = self.parse_subject_body(email_text)
        urls = self.extract_urls(body)
        subject_clean = self.apply_nlp(self.clean_text(subject))
        body_clean = self.apply_nlp(self.clean_text(body))
        combined_text = f"{subject_clean} {body_clean}".strip()
        return subject, body, subject_clean, body_clean, combined_text, urls


# ---------------------------------------------------------------------------
# Feature Extraction
# ---------------------------------------------------------------------------

class FeatureExtractor:
    """
    Extract hand-crafted features from preprocessed email components.

    All feature computations replicate feature_extraction.py from the
    training pipeline. Feature names and computation logic must remain
    identical to training to avoid shape mismatches when the model predicts.
    """

    def extract_features(self, email_text, subject, body, subject_clean, body_clean, urls):
        """
        Compute all hand-crafted features for a single email.

        Features are grouped into four categories:
            - Structural: length and word-count features
            - URL: count and suspicious-pattern features
            - Linguistic: character-level and keyword features
            - Sender: defaults used when sender info is unavailable

        Args:
            email_text    (str): Full raw email text.
            subject       (str): Parsed subject line (raw).
            body          (str): Parsed body text (raw).
            subject_clean (str): NLP-processed subject.
            body_clean    (str): NLP-processed body.
            urls          (list[str]): Extracted URLs.

        Returns:
            dict: Feature name → feature value mappings.
        """
        features = {}

        # -- Structural features ---------------------------------------------
        features['body_length']          = len(body)
        features['body_clean_length']    = len(body_clean)
        features['subject_length']       = len(subject)
        features['subject_clean_length'] = len(subject_clean)
        features['body_word_count']      = len(body_clean.split()) if body_clean else 0
        features['subject_word_count']   = len(subject_clean.split()) if subject_clean else 0
        features['total_word_count']     = features['body_word_count'] + features['subject_word_count']

        words = body_clean.split()
        features['avg_word_length'] = np.mean([len(w) for w in words]) if words else 0

        # -- URL features ----------------------------------------------------
        features['num_urls']          = len(urls)
        features['has_url']           = 1 if len(urls) > 0 else 0
        suspicious_patterns           = ['bit.ly', 'tinyurl', 'goo.gl', 'ow.ly', 'short', 'redirect']
        features['has_suspicious_url'] = 1 if any(
            p in str(urls).lower() for p in suspicious_patterns
        ) else 0

        # -- Linguistic features (computed on raw body) ----------------------
        features['num_uppercase']    = sum(1 for c in body if c.isupper())
        features['num_lowercase']    = sum(1 for c in body if c.islower())
        features['num_digits']       = sum(1 for c in body if c.isdigit())
        features['num_special_chars'] = sum(1 for c in body if not c.isalnum() and not c.isspace())
        features['num_exclamation']  = body.count('!')
        features['num_question']     = body.count('?')
        features['num_dots']         = body.count('.')

        total_letters = features['num_uppercase'] + features['num_lowercase']
        features['uppercase_ratio'] = (
            features['num_uppercase'] / total_letters if total_letters > 0 else 0
        )

        body_lower = body.lower()

        urgency_pattern = (
            r'\b(urgent|immediate|action required|verify|suspended|'
            r'limited time|act now|click here|confirm|update)\b'
        )
        features['has_urgency']   = 1 if re.search(urgency_pattern, body_lower) else 0

        financial_words = [
            'bank', 'account', 'payment', 'credit card', 'paypal', 'transaction',
            'money', 'dollar', 'refund', 'invoice', 'bill', 'tax'
        ]
        features['has_financial'] = 1 if any(w in body_lower for w in financial_words) else 0

        security_words = [
            'password', 'security', 'login', 'username', 'verify', 'authenticate',
            'credentials', 'access', 'blocked', 'locked'
        ]
        features['has_security']  = 1 if any(w in body_lower for w in security_words) else 0

        # -- Sender features (defaults when no sender info available) --------
        features['suspicious_sender'] = 0
        features['sender_missing']    = 1

        return features


# ---------------------------------------------------------------------------
# Core Prediction Function
# ---------------------------------------------------------------------------

# Module-level variable tracks the ID of the most recently saved prediction
# so the feedback function can reference it without requiring the user to
# copy an ID manually.
_last_prediction_id = None


def predict_phishing(email_text):
    """
    Run the full prediction pipeline on submitted email text and persist
    the result to the database.

    Pipeline steps:
        1. Validate input
        2. Preprocess (HTML strip, NLP lemmatization)
        3. Extract hand-crafted features
        4. Build TF-IDF feature vector
        5. Combine feature vectors and align column order
        6. Run Random Forest prediction
        7. Build human-readable indicators list
        8. Save result to SQLite via parameterized INSERT
        9. Return result, confidence, and indicators to the UI

    Args:
        email_text (str): Raw email text from the Gradio input widget.

    Returns:
        tuple[str, str, str]: (result_label, confidence_string, indicators_string)
    """
    global tfidf_vectorizer, _last_prediction_id

    if not email_text or len(email_text.strip()) == 0:
        return "Error", "Please enter some email text.", ""

    try:
        # Lazy-load TF-IDF vectorizer if it was not available at startup
        if tfidf_vectorizer is None:
            tfidf_path = Path('models/tfidf_vectorizer.pkl')
            if tfidf_path.exists():
                tfidf_vectorizer = joblib.load(tfidf_path)
                print("[MODEL] Loaded TF-IDF vectorizer (lazy).")
            else:
                return "Error", "TF-IDF vectorizer not found.", \
                       "Please run: python src/feature_extraction.py"

        # Step 1: Preprocess
        preprocessor = EmailPreprocessor()
        subject, body, subject_clean, body_clean, combined_text, urls = \
            preprocessor.preprocess(email_text)

        # Step 2: Hand-crafted features
        extractor = FeatureExtractor()
        features = extractor.extract_features(
            email_text, subject, body, subject_clean, body_clean, urls
        )

        # Step 3: TF-IDF features
        tfidf_matrix = tfidf_vectorizer.transform([combined_text])
        tfidf_feature_names = [
            f'tfidf_{name}' for name in tfidf_vectorizer.get_feature_names_out()
        ]
        tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), columns=tfidf_feature_names)

        # Step 4: Build hand-crafted feature DataFrame
        hand_crafted_data = {
            'body_length':          [features['body_length']],
            'body_clean_length':    [features['body_clean_length']],
            'subject_length':       [features['subject_length']],
            'subject_clean_length': [features['subject_clean_length']],
            'body_word_count':      [features['body_word_count']],
            'subject_word_count':   [features['subject_word_count']],
            'total_word_count':     [features['total_word_count']],
            'avg_word_length':      [features['avg_word_length']],
            'num_urls':             [features['num_urls']],
            'has_url':              [features['has_url']],
            'has_suspicious_url':   [features['has_suspicious_url']],
            'num_uppercase':        [features['num_uppercase']],
            'num_lowercase':        [features['num_lowercase']],
            'num_digits':           [features['num_digits']],
            'num_special_chars':    [features['num_special_chars']],
            'num_exclamation':      [features['num_exclamation']],
            'num_question':         [features['num_question']],
            'num_dots':             [features['num_dots']],
            'uppercase_ratio':      [features['uppercase_ratio']],
            'has_urgency':          [features['has_urgency']],
            'has_financial':        [features['has_financial']],
            'has_security':         [features['has_security']],
            'suspicious_sender':    [features['suspicious_sender']],
            'sender_missing':       [features['sender_missing']],
        }
        hand_crafted_df = pd.DataFrame(hand_crafted_data)

        # Step 5: Combine and align columns
        X = pd.concat([tfidf_df, hand_crafted_df], axis=1)
        if feature_names is not None:
            X = X[feature_names]

        # Step 6: Predict
        prediction = model.predict(X)[0]
        probability = model.predict_proba(X)[0]
        confidence = probability[prediction] * 100

        result = "PHISHING DETECTED" if prediction == 1 else "LEGITIMATE EMAIL"
        confidence_str = f"{confidence:.2f}%"

        # Step 7: Build indicators
        indicators = []
        if features['has_urgency']:
            indicators.append("Urgency keywords detected (urgent, immediate, verify, etc.)")
        if features['has_financial']:
            indicators.append("Financial keywords detected (bank, account, payment, etc.)")
        if features['has_security']:
            indicators.append("Security keywords detected (password, login, authenticate, etc.)")
        if features['uppercase_ratio'] > 0.3:
            indicators.append(
                f"High uppercase ratio ({features['uppercase_ratio']:.1%}) — possible shouting"
            )
        if features['num_exclamation'] > 3:
            indicators.append(f"Excessive exclamation marks ({features['num_exclamation']})")
        if features['has_suspicious_url']:
            indicators.append("Suspicious shortened URL detected")
        if features['num_urls'] > 5:
            indicators.append(f"High number of URLs ({features['num_urls']})")
        if not indicators:
            indicators.append("No obvious phishing indicators detected")

        indicators_str = "\n".join(indicators)

        # Step 8: Persist to database using parameterized INSERT
        _last_prediction_id = save_prediction(
            email_text, result, confidence_str, indicators_str
        )

        return result, confidence_str, indicators_str

    except Exception as e:
        import traceback
        return "Error", f"An error occurred: {str(e)}", traceback.format_exc()


def submit_feedback(correct_label, comment):
    """
    Save user feedback for the most recently analyzed email.

    Links the feedback to the last prediction via _last_prediction_id.
    All database access uses parameterized queries.

    Args:
        correct_label (str): The label the user believes is correct.
        comment       (str): Optional free-text explanation.

    Returns:
        str: A status message confirming success or reporting failure.
    """
    global _last_prediction_id

    if _last_prediction_id is None:
        return "No prediction found. Please analyze an email first."

    # Sanitize empty comment to empty string (never None)
    safe_comment = (comment or "").strip()

    success = save_feedback(_last_prediction_id, correct_label, safe_comment)
    if success:
        return (
            f"Thank you! Feedback recorded for prediction #{_last_prediction_id}. "
            f"Marked as: {correct_label}"
        )
    return "Failed to save feedback. Please try again."


def refresh_history():
    """
    Query the database and return a formatted prediction history string.

    Returns:
        str: Human-readable table of the 20 most recent predictions.
    """
    return format_history_table()


# ---------------------------------------------------------------------------
# Database Initialization
# ---------------------------------------------------------------------------

# Initialize the database at module load time. This is safe to call
# repeatedly — CREATE TABLE IF NOT EXISTS is idempotent.
init_db()


# ---------------------------------------------------------------------------
# Gradio Interface
# ---------------------------------------------------------------------------

with gr.Blocks(title="AI Phishing Email Detector", theme=gr.themes.Soft()) as demo:

    gr.Markdown("""
    # AI-Powered Phishing Email Detector
    ### Postgraduate Research Project — 99.74% Accuracy
    This system uses a **Random Forest machine learning model** trained on 10,000 emails.
    Paste any email text below to check if it is legitimate or phishing.
    All analyses are logged to a local SQLite database for audit and feedback purposes.
    ---
    """)

    # ── Tab 1: Analyze ────────────────────────────────────────────────────
    with gr.Tab("Analyze Email"):
        with gr.Row():
            with gr.Column():
                email_input = gr.Textbox(
                    label="Email Text",
                    placeholder=(
                        "Paste email content here (subject + body)...\n\n"
                        "Example:\n"
                        "Subject: Urgent: Your Account Has Been Suspended\n\n"
                        "Dear Customer,\n\n"
                        "Your account has been temporarily suspended..."
                    ),
                    lines=12
                )
                predict_btn = gr.Button("Analyze Email", variant="primary", size="lg")

            with gr.Column():
                result_output     = gr.Textbox(label="Prediction", lines=1)
                confidence_output = gr.Textbox(label="Confidence Score", lines=1)
                indicators_output = gr.Textbox(label="Detected Indicators", lines=8)

        gr.Markdown("### Try These Examples:")
        examples = [
            ["""Subject: Urgent Account Verification Required

Dear Customer,

Your PayPal account has been temporarily suspended due to unusual activity detected.

To restore full access, please verify your identity immediately by clicking the link below:

http://bit.ly/verify-paypal-account

Failure to verify within 24 hours will result in permanent account closure.

Best regards,
PayPal Security Team"""],

            ["""Subject: Team Meeting Tomorrow

Hi everyone,

Just a reminder that we have our weekly team meeting tomorrow at 2 PM in Conference Room B.

Agenda:
- Q4 project updates
- Budget review
- New hire introductions

Please bring your project status reports.

Thanks,
Sarah"""],

            ["""Subject: URGENT!!! You've Won $1,000,000!!!

CONGRATULATIONS!!!

You have been selected as the GRAND PRIZE WINNER of our international lottery!

CLAIM YOUR $1,000,000 NOW by clicking here: http://tinyurl.com/claim-prize

ACT IMMEDIATELY - This offer expires in 24 HOURS!!!

Click here to verify and receive your winnings!"""]
        ]
        gr.Examples(examples=examples, inputs=email_input, label="Click an example to test:")

        predict_btn.click(
            fn=predict_phishing,
            inputs=email_input,
            outputs=[result_output, confidence_output, indicators_output]
        )

    # ── Tab 2: Submit Feedback ────────────────────────────────────────────
    with gr.Tab("Submit Feedback"):
        gr.Markdown("""
        ### Was the last prediction correct?
        If the model made a mistake, use this form to submit a correction.
        Your feedback is saved to the database and can be used to improve the model.
        """)

        feedback_label = gr.Radio(
            choices=["LEGITIMATE EMAIL", "PHISHING DETECTED"],
            label="What should the correct label be?",
            value="LEGITIMATE EMAIL"
        )
        feedback_comment = gr.Textbox(
            label="Optional Comment",
            placeholder="Why do you think the prediction was wrong?",
            lines=3
        )
        feedback_btn    = gr.Button("Submit Feedback", variant="secondary")
        feedback_status = gr.Textbox(label="Status", lines=1)

        feedback_btn.click(
            fn=submit_feedback,
            inputs=[feedback_label, feedback_comment],
            outputs=feedback_status
        )

    # ── Tab 3: Prediction History ─────────────────────────────────────────
    with gr.Tab("Prediction History"):
        gr.Markdown("""
        ### Recent Analyses
        The table below shows the 20 most recent email analyses recorded in the database.
        Click **Refresh** to update.
        """)

        history_output  = gr.Textbox(
            label="Recent Predictions (last 20)",
            lines=25,
            value=format_history_table()
        )
        refresh_btn = gr.Button("Refresh History", variant="secondary")

        refresh_btn.click(
            fn=refresh_history,
            inputs=[],
            outputs=history_output
        )

    gr.Markdown("""
    ---
    ### About This System
    **Model:** Random Forest Classifier
    **Training Dataset:** 10,000 emails (5,000 phishing, 5,000 legitimate)
    **Performance:** 99.74% accuracy, 100% precision, 99.48% recall
    **Features:** 3,024 features including TF-IDF, structural, linguistic, and URL analysis
    **Database:** SQLite — all predictions and feedback persisted with parameterized queries

    **Note:** This is a research prototype. For production use, additional security
    measures and continuous model updates are recommended.
    """)

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("LAUNCHING PHISHING EMAIL DETECTOR WEB APP (v2.0)")
    print("=" * 60)
    print(f"\nDatabase: {DB_PATH}")
    print("\nStarting server...")
    print("\n" + "=" * 60 + "\n")

    demo.launch(share=False, show_error=True)
